﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Saraff.ThreadingModel;

namespace Saraff.Twain.MultithreadingSample2 {

    internal sealed partial class Form1:Form {
        private Twain32 _twain32;

        public Form1() {
            this.InitializeComponent();

            this._twain32=new SingleThreadedProxy(typeof(Twain32)).GetTransparentProxy() as Twain32;
            this._twain32.AcquireError+=_Twain32AcquireError;
            this._twain32.EndXfer+=_Twain32EndXfer;
            this._twain32.AcquireCompleted+=_Twain32AcquireCompleted;

            if(this.components==null) {
                this.components=new Container();
            }
            this.components.Add(_twain32);
        }

        protected async override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            try {
                this.EnabledInputControl=false;
                await Task.Run(() => this._twain32.OpenDSM());
                await Task.Run(() => this._twain32.ShowUI=false);

                #region Заполняем список источников данных

                this.dsToolStripComboBox.Items.Clear();
                for(int i = 0; i<await Task.Run(() => this._twain32.SourcesCount); i++) {
                    this.dsToolStripComboBox.Items.Add(await Task.Run(() => this._twain32.GetSourceProductName(i)));
                }
                if(await Task.Run(() => this._twain32.SourcesCount>0)) {
                    this.dsToolStripComboBox.SelectedIndex=await Task.Run(() => this._twain32.SourceIndex);
                }

                #endregion

            } catch(Exception ex) {
                MessageBox.Show(ex.Message,"SAMPLE2",MessageBoxButtons.OK,MessageBoxIcon.Error);
            } finally {
                this.EnabledInputControl=true;
            }
        }

        #region Twain32

        private void _Twain32AcquireCompleted(object sender,EventArgs e) {
            try {
                this.EnabledInputControl=true;
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,"SAMPLE2",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void _Twain32EndXfer(object sender,Twain32.EndXferEventArgs e) {
            try {
                this.CurrentBitmap=e.Image as Bitmap;
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,"SAMPLE2",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void _Twain32AcquireError(object sender,Twain32.AcquireErrorEventArgs e) {
            try {
                this.EnabledInputControl=true;
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,"SAMPLE2",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Toolbar

        private async void dsToolStripComboBox_SelectedIndexChanged(object sender,EventArgs e) {
            try {
                await Task.Run(() => this._twain32.CloseDataSource());
                this._twain32.SourceIndex=this.dsToolStripComboBox.SelectedIndex;
                await Task.Run(() => this._twain32.OpenDataSource());

                #region Заполняем список доступных разрешений dpi

                this.resolutionToolStripDropDownButton.DropDownItems.Clear();
                Twain32.Enumeration _resolutions = await Task.Run(() => this._twain32.Capabilities.XResolution.Get());
                if(_resolutions.Count<20) {
                    for(int i = 0; i<_resolutions.Count; i++) {

                        this.resolutionToolStripDropDownButton.DropDownItems.Add(
                            string.Format("{0:N0} dpi",_resolutions[i]),
                            null,
                            _ResolutionItemSelected).Tag=_resolutions[i];
                    }
                    this._ResolutionItemSelected(this.resolutionToolStripDropDownButton.DropDownItems[_resolutions.CurrentIndex],new EventArgs());
                } else {
                    foreach(var _val in new float[] { 100f,200f,300f,600f,1200f,2400f }) {
                        for(int i = _resolutions.Count-1; i>=0; i--) {
                            if(Math.Abs((float)_resolutions[i]-_val)<50f) {
                                var _item = this.resolutionToolStripDropDownButton.DropDownItems.Add(
                                    string.Format("{0:N0} dpi",_val),
                                    null,
                                    _ResolutionItemSelected);
                                _item.Tag=_resolutions[i];
                                if(i==_resolutions.CurrentIndex) {
                                    this._ResolutionItemSelected(_item,new EventArgs());
                                }
                                break;
                            }
                        }
                    }
                }

                #endregion

                #region Заполняем список доступных типов пикселей

                this.pixelTypeToolStripDropDownButton.DropDownItems.Clear();
                Twain32.Enumeration _pixelTypes = await Task.Run(() => this._twain32.Capabilities.PixelType.Get());
                for(int i = 0; i<_pixelTypes.Count; i++) {
                    this.pixelTypeToolStripDropDownButton.DropDownItems.Add(
                        _pixelTypes[i].ToString(),
                        null,
                        _PixelTypeItemSelected).Tag=_pixelTypes[i];
                }
                this._PixelTypeItemSelected(this.pixelTypeToolStripDropDownButton.DropDownItems[_pixelTypes.CurrentIndex],new EventArgs());

                #endregion

                this.pictureBox1.Select();
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private async void newToolStripButton_Click(object sender,EventArgs e) {
            try {
                this.EnabledInputControl=false;
                await Task.Run(() => this._twain32.Acquire());
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void saveToolStripButton_Click(object sender,EventArgs e) {
            try {
                if(this.saveFileDialog1.ShowDialog()==DialogResult.OK) {
                    this.pictureBox1.Image.Save(this.saveFileDialog1.FileName,ImageFormat.Bmp);
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void copyToolStripButton_Click(object sender,EventArgs e) {
            try {
                Clipboard.SetImage(this.CurrentBitmap);
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        private async void _ResolutionItemSelected(object sender,EventArgs e) {
            try {
                ToolStripItem _item = sender as ToolStripItem;
                if(_item!=null) {
                    this.resolutionToolStripDropDownButton.Text=_item.Text;
                    this.resolutionToolStripDropDownButton.Tag=_item.Tag;
                    await Task.Run(() => this._twain32.Capabilities.XResolution.Set((float)_item.Tag));
                    await Task.Run(() => this._twain32.Capabilities.YResolution.Set((float)_item.Tag));
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private async void _PixelTypeItemSelected(object sender,EventArgs e) {
            try {
                ToolStripItem _item = sender as ToolStripItem;
                if(_item!=null) {
                    this.pixelTypeToolStripDropDownButton.Text=_item.Text;
                    this.pixelTypeToolStripDropDownButton.Tag=_item.Tag;
                    await Task.Run(() => this._twain32.Capabilities.PixelType.Set((TwPixelType)_item.Tag));
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private Bitmap CurrentBitmap {
            get {
                return this.pictureBox1.Image as Bitmap;
            }
            set {
                var _action = new Action(() => {
                    if(this.pictureBox1.Image!=null) {
                        this.pictureBox1.Image.Dispose();
                    }
                    this.pictureBox1.Image=value;
                });
                if(this.InvokeRequired) {
                    this.Invoke(_action);
                } else {
                    _action();
                }
            }
        }

        private bool EnabledInputControl {
            get {
                return this.toolStrip1.Enabled;
            }
            set {
                Action<bool> _action = val => this.toolStrip1.Enabled=val;
                if(this.InvokeRequired) {
                    this.Invoke(_action,value);
                } else {
                    _action(value);
                }
            }
        }
    }
}
