﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Windows.Browser;
using System.IO;
using System.Runtime.InteropServices;
using System.ServiceModel;
using System.ServiceModel.DomainServices.Client;
using Saraff.Twain.SL.Extensions;
using TW=Saraff.Twain.SL.TwainServiceReference;
using UP=Saraff.Twain.SL.UploadServiceReference;

namespace Saraff.Twain.SL {

    public partial class Sample1:UserControl {
        private TW.ITwainService _service=new TW.TwainServiceClient();
        private UP.IUploadServiceChannel _uploader;
        private ObservableCollection<string> _uploadCollection=new ObservableCollection<string>();

        public Sample1() {
            InitializeComponent();
            this._uploadedFiles.Source=this._uploadCollection;
        }

        private void _Load() {
            this.busyIndicator.IsBusy=true;
            this.busyIndicator.BusyContent="Getting a datasources...";
            this._service.BeginGetSources(result => {
                this.Dispatcher.BeginInvoke(() => {
                    try {
                        for(var _sources=this._service.EndGetSources(result); _service!=null&&_sources.Count>0; ) {
                            this._twainSources.Source=_sources;
                            for(var i=0; i<_sources.Count; i++) {
                                if(_sources[i].IsDefault) {
                                    this._twainSources.View.MoveCurrentToPosition(i);
                                    break;
                                }
                            }
                            this._twainSources.View.CurrentChanged+=this._TwainSourceCurrentChanged;
                            this._GetCaps();
                            break;
                        }
                        for(var _script=HtmlPage.Window.GetProperty("onHideReq") as ScriptObject; _script!=null; ) {
                            _script.InvokeSelf();
                            break;
                        }
                    } catch(Exception ex) {
                        this.busyIndicator.IsBusy=false;
                        ex.Show();
                    }
                });
            },null);
        }

        private void _GetCaps() {
            this.busyIndicator.IsBusy=true;
            this.busyIndicator.BusyContent="Getting a capabilities...";
            var _ds=this._twainSources.View.CurrentItem as TW.Source;
            this._service.BeginGetCaps(
                _ds,
                new Collection<TW.TwCap> {
                        TW.TwCap.XResolution,
                        TW.TwCap.IPixelType
                    },
                result => {
                    this.Dispatcher.BeginInvoke(() => {
                        try {
                            var _res=this._service.EndGetCaps(result);

                            #region XResolution

                            for(var _cap=_res.FirstOrDefault(cap => cap.Cap==TW.TwCap.XResolution); _cap!=null; ) {
                                this._resolutions.Source=_cap.Values;
                                this._resolutions.View.MoveCurrentTo(_cap.Current);
                                break;
                            }

                            #endregion

                            #region IPixelType

                            for(var _cap=_res.FirstOrDefault(cap => cap.Cap==TW.TwCap.IPixelType); _cap!=null; ) {
                                this._pixelTypes.Source=_cap.Values;
                                this._pixelTypes.View.MoveCurrentTo(_cap.Current);
                                break;
                            }

                            #endregion

                            this.busyIndicator.IsBusy=false;
                        } catch(Exception ex) {
                            this.busyIndicator.IsBusy=false;
                            ex.Show();
                        }
                    });
                },
                null);
        }

        private void _Acquire() {
            this.busyIndicator.IsBusy=true;
            this.busyIndicator.BusyContent="Acquiring...";
            this._service.BeginAcquire(
                this._twainSources.View.CurrentItem as TW.Source,
                new Collection<TW.CapEnum>{
                    new TW.CapEnum{Cap=TW.TwCap.XResolution,Current=this._resolutions.View.CurrentItem as TW.CapValue},
                    new TW.CapEnum{Cap=TW.TwCap.YResolution,Current=this._resolutions.View.CurrentItem as TW.CapValue},
                    new TW.CapEnum{Cap=TW.TwCap.IPixelType,Current=this._pixelTypes.View.CurrentItem as TW.CapValue}},
                result => {
                    this.Dispatcher.BeginInvoke(() => {
                        try {
                            byte[] _image;
                            using(var _stream=new MemoryStream(_image=this._service.EndAcquire(result))) {
                                var _img=new BitmapImage {
                                    CreateOptions=BitmapCreateOptions.None
                                };
                                _stream.Seek(0,SeekOrigin.Begin);
                                _img.SetSource(_stream);
                                this._imageControl.Source=_img;
                                this.busyIndicator.IsBusy=false;
                            }
                            this.busyIndicator.BusyContent="Uploading...";
                            this._Uploader.BeginUpload(_image,
                                result2 => {
                                    this.Dispatcher.BeginInvoke(() => {
                                        try {
                                            this._uploadCollection.Add(this._Uploader.EndUpload(result2));
                                            this._uploadedFiles.View.MoveCurrentToLast();
                                            this.busyIndicator.IsBusy=false;
                                        } catch(Exception ex) {
                                            this.busyIndicator.IsBusy=false;
                                            ex.Show();
                                        } finally {
                                            this._Uploader=null;
                                        }
                                    });
                                },
                                null);
                        } catch(Exception ex) {
                            this.busyIndicator.IsBusy=false;
                            ex.Show();
                        }
                    });
                },
                null);
        }

        private UP.IUploadService _Uploader {
            get {
                if(this._uploader==null) {
                    var _uri=HtmlPage.Document.DocumentUri.AbsoluteUri;
                    var _factory=new ChannelFactory<UP.IUploadServiceChannel>("BasicHttpBinding_IUploadService",new EndpointAddress(string.Format("{0}/UploadService.svc",_uri.Substring(0,_uri.LastIndexOf('/')))));
                    this._uploader=_factory.CreateChannel();
                }
                return this._uploader;
            }
            set {
                if(value!=null) {
                    throw new ArgumentException();
                }
                if(this._uploader!=null) {
                    this._uploader.Dispose();
                }
                this._uploader=null;
            }
        }

        #region Handlers

        private void _TwainSourceCurrentChanged(object sender,EventArgs e) {
            try {
                this._GetCaps();
            } catch(Exception ex) {
                ex.Show();
            }
        }

        private void LayoutRoot_Loaded(object sender,RoutedEventArgs e) {
            try {
                this._Load();
            } catch(Exception ex) {
                ex.Show();
            }
        }

        private void acquireButton_Click(object sender,RoutedEventArgs e) {
            try {
                this._Acquire();
            } catch(Exception ex) {
                ex.Show();
            }
        }

        #endregion
    }
}
