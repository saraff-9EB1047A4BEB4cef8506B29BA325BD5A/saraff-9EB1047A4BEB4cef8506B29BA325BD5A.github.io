﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Saraff.IoC;
using Saraff.Twain;

[assembly: BindService(typeof(IStreamProvider),typeof(Saraff.Twain.DependencyInjection3._StreamProvider))]
[assembly: BindService(typeof(IImageHandler),typeof(Saraff.Twain.DependencyInjection3._DibImageHandler))]

namespace Saraff.Twain.DependencyInjection3 {

    internal sealed class Program {

        [STAThread]
        private static void Main(string[] args) {
            try {
                using(var _container = new ServiceContainer()) {
                    _container.Load(typeof(Program).Assembly);

                    using(var _twain = _container.CreateInstance<Twain32>()) {
                        _twain.SelectSource();

                        _twain.EndXfer += (sender,e) => {
                            using(var _image = e.Image) {
                                _image.Save(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Path.ChangeExtension(Path.GetFileName(Path.GetTempFileName()),".bmp")));
                            }
                        };

                        _twain.AcquireError += (sender,e) => Program._ToLog(e.Exception);

                        _twain.Acquire();
                    }
                }
            } catch(Exception ex) {
                Program._ToLog(ex);
            }
        }

        private static void _ToLog(Exception ex) {
            Console.WriteLine("<exception>");
            Console.WriteLine();
            for(var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Console.WriteLine("{0}: {1}",_ex.GetType().Name,_ex.Message);
                Console.WriteLine("Stack Trace:");
                Console.WriteLine(_ex.StackTrace);
                Console.WriteLine();
            }
            Console.WriteLine("</exception>");
        }
    }

    internal sealed class _StreamProvider:Component, IStreamProvider {

        public Stream GetStream() {
            return new FileStream(Path.GetTempFileName(),FileMode.Create,FileAccess.ReadWrite,FileShare.Read,64 * 1024,FileOptions.DeleteOnClose);
        }
    }

    internal sealed class _DibImageHandler:Component, IImageHandler {
        private const int BufferSize = 256 * 1024;

        public Stream PtrToStream(IntPtr ptr,IStreamProvider provider) {
            var _stream = provider?.GetStream() ?? new MemoryStream();
            var _writer = new BinaryWriter(_stream);

            int _size = _DibImageHandler.GlobalSize(_DibImageHandler.GlobalHandle(ptr));

            #region Write BITMAPFILEHEADER to stream

            BITMAPINFOHEADER _header = Marshal.PtrToStructure(ptr,typeof(BITMAPINFOHEADER)) as BITMAPINFOHEADER;

            _writer.Write((ushort)0x4d42);
            _writer.Write(14 + _size);
            _writer.Write(0);
            _writer.Write(14 + _header.biSize + (_header.ClrUsed << 2));

            #endregion

            byte[] _buffer = new byte[_DibImageHandler.BufferSize];

            #region  Copy data to stream

            for(int _offset = 0, _len = 0; _offset < _size; _offset += _len) {
                _len = Math.Min(_DibImageHandler.BufferSize,_size - _offset);
                Marshal.Copy((IntPtr)(ptr.ToInt64() + _offset),_buffer,0,_len);
                _writer.Write(_buffer,0,_len);
            }

            #endregion

            return _stream;
        }

        [DllImport("kernel32.dll")]
        private static extern IntPtr GlobalHandle(IntPtr pMem);

        [DllImport("kernel32.dll")]
        private static extern int GlobalSize(IntPtr hMem);

        [StructLayout(LayoutKind.Sequential,Pack = 2)]
        private class BITMAPINFOHEADER {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;

            public int ClrUsed {
                get {
                    return this.IsRequiredCreateColorTable ? 1 << this.biBitCount : this.biClrUsed;
                }
            }

            public bool IsRequiredCreateColorTable {
                get {
                    return this.biClrUsed == 0 && this.biBitCount <= 8;
                }
            }
        }
    }
}
