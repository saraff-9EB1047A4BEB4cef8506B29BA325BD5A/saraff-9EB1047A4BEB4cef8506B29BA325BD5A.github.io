﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Saraff.IoC;
using Saraff.Twain;

[assembly: BindService(typeof(IStreamProvider),typeof(Saraff.Twain.DependencyInjection1._StreamProvider))]

namespace Saraff.Twain.DependencyInjection1 {

    internal sealed class Program {

        [STAThread]
        private static void Main(string[] args) {
            try {
                using(var _container = new ServiceContainer()) {
                    _container.Load(typeof(Program).Assembly);

                    using(var _twain = _container.CreateInstance<Twain32>()) {
                        _twain.SelectSource();

                        _twain.EndXfer += (sender,e) => {
                            using(var _image = e.Image) {
                                _image.Save(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Path.ChangeExtension(Path.GetFileName(Path.GetTempFileName()),".bmp")));
                            }
                        };

                        _twain.AcquireError += (sender,e) => Program._ToLog(e.Exception);

                        _twain.Acquire();
                    }
                }
            } catch(Exception ex) {
                Program._ToLog(ex);
            }
        }

        private static void _ToLog(Exception ex) {
            Console.WriteLine("<exception>");
            Console.WriteLine();
            for(var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Console.WriteLine("{0}: {1}",_ex.GetType().Name,_ex.Message);
                Console.WriteLine("Stack Trace:");
                Console.WriteLine(_ex.StackTrace);
                Console.WriteLine();
            }
            Console.WriteLine("</exception>");
        }
    }

    internal sealed class _StreamProvider:Component, IStreamProvider {

        public Stream GetStream() {
            return new FileStream(Path.GetTempFileName(),FileMode.Create,FileAccess.ReadWrite,FileShare.Read,64*1024,FileOptions.DeleteOnClose);
        }
    }
}
