﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Text;
using Saraff.Twain;
using System.Drawing.Imaging;
using System.Reflection;
using System.IO;
using System.Linq;
using Saraff.Twain.Extensions;

namespace Saraff.Twain.Sample3 {

    internal sealed class Program {

        [STAThread]
        private static void Main(string[] args) {
            try {
                var _asm=typeof(Twain32).Assembly;
                Console.WriteLine(
                    "{1} {2}{0}{3}{0}",
                    Environment.NewLine,
                    ((AssemblyTitleAttribute)_asm.GetCustomAttributes(typeof(AssemblyTitleAttribute),false)[0]).Title,
                    ((AssemblyFileVersionAttribute)_asm.GetCustomAttributes(typeof(AssemblyFileVersionAttribute),false)[0]).Version,
                    ((AssemblyCopyrightAttribute)_asm.GetCustomAttributes(typeof(AssemblyCopyrightAttribute),false)[0]).Copyright);

                bool _isShowUI = true, _IsTwain2Enable = true;

                #region ShowUI

                Console.Write("ShowUI {0}: ",_isShowUI ? "[Y/n]":"[y/N]");
                for(var _res=Console.ReadLine().Trim().ToUpper(); !string.IsNullOrEmpty(_res); ) {
                    _isShowUI=_res=="Y";
                    break;
                }
                Console.WriteLine("ShowUI = {0}",_isShowUI ? "Y":"N");

                #endregion

                #region IsTwain2Enable

                Console.Write("IsTwain2Enable {0}: ",_IsTwain2Enable ? "[Y/n]":"[y/N]");
                for(var _res=Console.ReadLine().Trim().ToUpper(); !string.IsNullOrEmpty(_res); ) {
                    _IsTwain2Enable=_res=="Y";
                    break;
                }
                Console.WriteLine("IsTwain2Enable = {0}",_IsTwain2Enable ? "Y":"N");

                #endregion

                using(var _dsm = XDsm.Create(_IsTwain2Enable,_isShowUI)) {

                    if(_dsm.IsTwain2Supported) {
                        Console.WriteLine("IsTwain2Supported = {0}",_dsm.IsTwain2Supported?"Y":"N");
                    }

                    #region Select Data Source

                    Console.WriteLine();
                    Console.WriteLine("Select Data Source:");
                    foreach(var _item in _dsm.DataSources.Select((x,i) => new {Index = i, Identity = x.Identity, IsTwain2Compatible = x.IsTwain2Compatible})) {
                        Console.WriteLine("{0}: {1}{2}",_item.Index,_item.Identity.Name,_dsm.IsTwain2Supported&&_item.IsTwain2Compatible ? " (TWAIN 2.x)" : string.Empty);
                    }

                    int _dsIndex;
                    Console.Write("[{0}]: ",_dsIndex = _dsm.DataSources.Select((x,i) => new {Index = i,IsDefault = x.IsDefault}).First(x => x.IsDefault).Index);
                    for(var _res=Console.ReadLine().Trim(); !string.IsNullOrEmpty(_res); ) {
                        _dsIndex=Convert.ToInt32(_res);
                        break;
                    }
                    var _ds = _dsm.DataSources.ElementAtOrDefault(_dsIndex);
                    if(_ds==null) {
                        throw new InvalidOperationException("Invalid a Data Source index.");
                    }
                    Console.WriteLine(string.Format("Data Source: {0}",_ds.Identity.Name));

                    #endregion

                    if(!_isShowUI) {

                        #region Select Resolution

                        Console.WriteLine();
                        Console.WriteLine("Select Resolution:");
                        var _resolutions = _ds.GetCapability<float>(TwCap.XResolution).Values.Select((x,i) => new {
                            Index = i,
                            Value = x.Value,
                            IsCurrent = x.IsCurrent
                        });
                        foreach(var _item in _resolutions) {
                            Console.WriteLine("{0}: {1} dpi",_item.Index,_item.Value);
                        }
                        Console.Write("[{0}]: ",_resolutions.First(x => x.IsCurrent).Index);
                        for(var _res=Console.ReadLine().Trim(); !string.IsNullOrEmpty(_res); ) {
                            var _val=_resolutions.ElementAt(Convert.ToInt32(_res)).Value;
                            _ds
                                .GetCapability<float>(TwCap.XResolution).Set(x => _val).DataSource
                                .GetCapability<float>(TwCap.YResolution).Set(x => _val);
                            break;
                        }
                        Console.WriteLine(string.Format("Resolution: {0}",_ds.GetCapability<float>(TwCap.XResolution).Values.First(x => x.IsCurrent).Value));

                        #endregion

                        #region Select Pixel Type

                        Console.WriteLine();
                        Console.WriteLine("Select Pixel Type:");
                        var _pixels = _ds.GetCapability<TwPixelType>(TwCap.IPixelType).Values.Select((x,i) => new {
                            Index = i,
                            Value = x.Value,
                            IsCurrent = x.IsCurrent,
                            Cap = x
                        });
                        foreach(var _item in _pixels) {
                            Console.WriteLine("{0}: {1}",_item.Index,_item.Value);
                        }
                        Console.Write("[{0}]: ",_pixels.First(x => x.IsCurrent).Index);
                        for(var _res=Console.ReadLine().Trim(); !string.IsNullOrEmpty(_res); ) {
                            _pixels.ElementAt(Convert.ToInt32(_res)).Cap.Set();
                            break;
                        }
                        Console.WriteLine(string.Format("Pixel Type: {0}",_ds.GetCapability<TwPixelType>(TwCap.IPixelType).Values.First(x => x.IsCurrent).Value));

                        #endregion

                    }

                    _ds.NativeTransfer(
                        x => {
                            using(var _image = x.Image) {
                                var _file = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Path.ChangeExtension(Path.GetFileName(Path.GetTempFileName()),".jpg"));
                                _image.Save(_file,ImageFormat.Jpeg);
                                Console.WriteLine();
                                Console.WriteLine(string.Format("Saved in: {0}",_file));
                            }
                        },
                        null,
                        () => {
                            Console.WriteLine();
                            Console.WriteLine("Acquire Completed.");
                        },
                        x => {
                            Console.WriteLine();
                            Console.WriteLine("Acquire Error: ReturnCode = {0}; ConditionCode = {1};",x.Exception.ReturnCode,x.Exception.ConditionCode);
                            Program.WriteException(x.Exception);
                        });
                }
            } catch(Exception ex) {
                Program.WriteException(ex);
            }
        }

        private static void WriteException(Exception ex) {
            for(var _ex=ex; _ex!=null; _ex=_ex.InnerException) {
                Console.WriteLine("{0}: {1}{2}{3}{2}",_ex.GetType().Name,_ex.Message,Environment.NewLine,_ex.StackTrace);
            }
        }
    }
}
