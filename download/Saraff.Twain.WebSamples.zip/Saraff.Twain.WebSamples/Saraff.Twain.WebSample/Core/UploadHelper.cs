﻿/* Этот файл является частью примеров использования библиотек Saraff.Twain.NET и Saraff.AxHost.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;

namespace Saraff.Twain.WebSample.Core {

    internal sealed class UploadHelper {

        private UploadHelper() {
        }

        public static UploadHelper Create(string uri) {
            return new UploadHelper {
                Uri=new Uri(uri)
            };
        }

        public void Upload(Stream stream, string extension, out string name) {
            name=this._Create(extension);
            var _buf=new byte[8*1024];
            while(true) {
                var _readed=stream.Read(_buf, 0, _buf.Length);
                this._Append(name, _buf, 0, _readed);
                if(_readed<_buf.Length) {
                    break;
                }
            }
        }

        private string _Create(string extension) {
            var _ext=Encoding.UTF8.GetBytes(extension);
            return Encoding.UTF8.GetString(this._Send(1, _ext, 0, _ext.Length));
        }

        private void _Append(string name, byte[] data, int offset, int count) {
            using(var _stream=new MemoryStream()) {
                var _name=Encoding.UTF8.GetBytes(name);
                _stream.WriteByte((byte)_name.Length);
                _stream.Write(_name, 0, _name.Length);
                _stream.Write(data, offset, count);
                var _data=_stream.ToArray();
                this._Send(2, _data, 0, _data.Length);
            }
        }

        private byte[] _Send(byte code, byte[] data, int offset, int count) {
            var _request=WebRequest.Create(this.Uri);
            _request.Method="POST";
            _request.ContentType="application/octet-stream";
            using(var _writer=new BinaryWriter(_request.GetRequestStream())) {
                _writer.Write(code);
                _writer.Write(count);
                _writer.Write(data, offset, count);
            }
            using(var _reader=new BinaryReader(_request.GetResponse().GetResponseStream())) {
                switch(_reader.ReadByte()) {
                    case 0x00:
                        return _reader.ReadBytes(_reader.ReadInt32());
                    case 0xff:
                        throw new InvalidOperationException(Encoding.UTF8.GetString(_reader.ReadBytes(_reader.ReadInt32())));
                    default:
                        throw new InvalidOperationException();
                }
            }
        }

        public Uri Uri {
            get;
            private set;
        }
    }
}
