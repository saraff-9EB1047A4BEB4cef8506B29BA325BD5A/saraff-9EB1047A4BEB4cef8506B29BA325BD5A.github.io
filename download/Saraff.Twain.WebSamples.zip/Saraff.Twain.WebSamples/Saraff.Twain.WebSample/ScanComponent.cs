﻿/* Этот файл является частью примеров использования библиотек Saraff.Twain.NET и Saraff.AxHost.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;
using Saraff.AxHost;
using Saraff.Twain.WebSample.Core;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace Saraff.Twain.WebSample {

    [ApplicationComponent]
    public sealed partial class ScanComponent:ApplicationComponent {
        private UploadHelper _helper;
        private Twain32.Enumeration _resolutions;

        public ScanComponent() {
            InitializeComponent();
        }

        public ScanComponent(IContainer container) {
            container.Add(this);

            InitializeComponent();
        }

        protected override void Construct(ReadOnlyCollection<object> args) {
            try {
                this._twain32.OpenDSM();
                if(args!=null&&args.Count>0) {
                    this._helper=UploadHelper.Create(args[0].ToString());
                } else {
                    throw new InvalidOperationException("TwainHandler URI not set.");
                }
            } catch(Exception ex) {
                Debug.WriteLine(string.Format("{1}: {2}{0}{3}{0}", Environment.NewLine, ex.GetType().Name, ex.Message, ex.StackTrace), "ERROR");
            }
            base.Construct(args);
        }

        [ApplicationProcessed]
        public int GetCurrentSourceIndex() {
            return this._twain32.SourceIndex;
        }

        [ApplicationProcessed]
        public int GetSourcesCount() {
            return this._twain32.SourcesCount;
        }

        [ApplicationProcessed]
        public string GetSourceProductName(int index) {
            return this._twain32.GetSourceProductName(index);
        }

        [ApplicationProcessed]
        public void LoadDS(int index) {
            this._twain32.CloseDataSource();
            this._twain32.SourceIndex=index;
            this._twain32.OpenDataSource();

            this._resolutions=this._twain32.Capabilities.XResolution.Get();
        }

        [ApplicationProcessed]
        public int GetCurrentResolutionIndex() {
            if(this._resolutions!=null) {
                return this._resolutions.CurrentIndex;
            } else {
                return -1;
            }
        }

        [ApplicationProcessed]
        public int GetResolutionsCount() {
            if(this._resolutions!=null) {
                return this._resolutions.Count;
            } else {
                return -1;
            }
        }

        [ApplicationProcessed]
        public float GetResolutionValue(int index) {
            if(this._resolutions!=null) {
                return (float)this._resolutions[index];
            } else {
                return -1;
            }
        }

        [ApplicationProcessed]
        public void SetResolution(int index) {
            this._twain32.Capabilities.XResolution.Set((float)this._resolutions[index]);
            this._twain32.Capabilities.YResolution.Set((float)this._resolutions[index]);
        }

        [ApplicationProcessed]
        public void Acquire() {
            this._twain32.Acquire();
        }

        private void _Upload(Image image) {
            using(var _stream=new MemoryStream()) {
                image.Save(_stream, ImageFormat.Jpeg);
                _stream.Seek(0, SeekOrigin.Begin);

                this.OnUploading(new EventArgs());
                string _name;
                this._helper.Upload(_stream, ".jpg", out _name);
                this.OnUploaded(new UploadEventArgs(_name));
            }
        }

        #region Twain32 events handlers

        private void _twain32_EndXfer(object sender, Twain32.EndXferEventArgs e) {
            try {
                this._Upload(e.Image);
                e.Image.Dispose();
            } catch(Exception ex) {
                Debug.WriteLine(string.Format("{1}: {2}{0}{3}{0}", Environment.NewLine, ex.GetType().Name, ex.Message, ex.StackTrace), "ERROR");
            }
        }

        private void _twain32_AcquireError(object sender, Twain32.AcquireErrorEventArgs e) {
            try {
                this.OnError(new Saraff.Twain.WebSample.Core.ErrorEventArgs(string.Format("{4}{0}: {1} ConditionCode = {2}; ReturnCode = {3};{4}", e.Exception.GetType().Name, e.Exception.Message, e.Exception.ConditionCode, e.Exception.ReturnCode, Environment.NewLine)));
            } catch(Exception ex) {
                Debug.WriteLine(string.Format("{1}: {2}{0}{3}{0}", Environment.NewLine, ex.GetType().Name, ex.Message, ex.StackTrace), "ERROR");
            }
        }

        #endregion

        #region Private Events Handlers

        private void OnUploading(EventArgs e) {
            if(this.Uploading!=null) {
                this.Uploading(this, e);
            }
        }

        private void OnUploaded(UploadEventArgs e) {
            if(this.Uploaded!=null) {
                this.Uploaded(this, e);
            }
        }

        private void OnError(Saraff.Twain.WebSample.Core.ErrorEventArgs e) {
            if(this.Error!=null) {
                this.Error(this, e);
            }
        }

        #endregion

        #region Events

        [ApplicationProcessed]
        public event EventHandler Uploading;

        [ApplicationProcessed]
        public event EventHandler Uploaded;

        [ApplicationProcessed]
        public event EventHandler Error;

        #endregion
    }
}
