﻿/* Этот файл является частью примеров использования библиотек Saraff.Twain.NET и Saraff.AxHost.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Net;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using Saraff.AxHost;
using Saraff.Tiff;
using Saraff.Tiff.Core;
using Saraff.Twain.WebSample.Core;

namespace Saraff.Twain.WebSample {

    [ApplicationControl(Width=640,Height=480)]
    public sealed partial class ScanControl:ApplicationControl {
        private UploadHelper _helper;

        public ScanControl() {
            InitializeComponent();
        }

        protected override void Construct(ReadOnlyCollection<object> args) {
            try {
                this._LoadDSM();
                if(args!=null&&args.Count>0) {
                    this._helper=UploadHelper.Create(args[0].ToString());
                } else {
                    throw new InvalidOperationException("TwainHandler URI not set.");
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            base.Construct(args);
        }

        private void _LoadDSM() {
            this._twain32.OpenDSM();

            #region Заполняем список источников данных

            this.dataSourceToolStripComboBox.Items.Clear();
            for(int i=0; i<this._twain32.SourcesCount; i++) {
                this.dataSourceToolStripComboBox.Items.Add(this._twain32.GetSourceProductName(i));
            }
            if(this._twain32.SourcesCount>0) {
                this.dataSourceToolStripComboBox.SelectedIndex=this._twain32.SourceIndex;
            }

            #endregion
        }

        private void _LoadDS() {
            this._twain32.CloseDataSource();
            this._twain32.SourceIndex=this.dataSourceToolStripComboBox.SelectedIndex;
            this._twain32.OpenDataSource();

            #region Заполняем список доступных разрешений dpi

            this.dpiToolStripDropDownButton.DropDownItems.Clear();
            Twain32.Enumeration _resolutions=this._twain32.Capabilities.XResolution.Get();
            if(_resolutions.Count<20) {
                for(int i=0; i<_resolutions.Count; i++) {
                    this.dpiToolStripDropDownButton.DropDownItems.Add(
                        string.Format("{0:N0} dpi", _resolutions[i]),
                        null,
                        _ResolutionItemSelected).Tag=_resolutions[i];
                }
                this._SetResolution(this.dpiToolStripDropDownButton.DropDownItems[_resolutions.DefaultIndex]);
            }

            #endregion

            #region Заполняем список доступных типов пикселей

            this.pixelTypeToolStripDropDownButton.DropDownItems.Clear();
            Twain32.Enumeration _pixelTypes=this._twain32.Capabilities.PixelType.Get();
            for(int i=0; i<_pixelTypes.Count; i++) {
                this.pixelTypeToolStripDropDownButton.DropDownItems.Add(
                    _pixelTypes[i].ToString(),
                    null,
                    _PixelTypeItemSelected).Tag=_pixelTypes[i];
            }
            this._SetPixelType(this.pixelTypeToolStripDropDownButton.DropDownItems[_pixelTypes.DefaultIndex]);

            #endregion

            #region Заполняем список доступных способов передачи данных

            this.xferMechToolStripDropDownButton.DropDownItems.Clear();
            Twain32.Enumeration _xferMech=this._twain32.Capabilities.XferMech.Get();
            for(int i=0; i<_xferMech.Count; i++) {
                this.xferMechToolStripDropDownButton.DropDownItems.Add(
                    _xferMech[i].ToString(),
                    null,
                    _XferMechItemSelected).Tag=_xferMech[i];
            }
            this._SetXferMech(this.xferMechToolStripDropDownButton.DropDownItems[_xferMech.DefaultIndex]);

            #endregion

            #region Заполняем списов доступных форматов изображения

            this.fileFormatToolStripDropDownButton.DropDownItems.Clear();
            Twain32.Enumeration _format=this._twain32.Capabilities.ImageFileFormat.Get();
            for(int i=0; i<_format.Count; i++) {
                this.fileFormatToolStripDropDownButton.DropDownItems.Add(
                    _format[i].ToString(),
                    null,
                    _FileFormatSelected).Tag=_format[i];
            }
            this._SetFileFormat(this.fileFormatToolStripDropDownButton.DropDownItems[_format.DefaultIndex]);

            #endregion
        }

        private void _SetResolution(ToolStripItem item) {
            this.dpiToolStripDropDownButton.Text=item.Text;
            this.dpiToolStripDropDownButton.Tag=item.Tag;
            this._twain32.Capabilities.XResolution.Set((float)item.Tag);
            this._twain32.Capabilities.YResolution.Set((float)item.Tag);
        }

        private void _SetPixelType(ToolStripItem item) {
            this.pixelTypeToolStripDropDownButton.Text=item.Text;
            this.pixelTypeToolStripDropDownButton.Tag=item.Tag;
            this._twain32.Capabilities.PixelType.Set((TwPixelType)item.Tag);
        }

        private void _SetXferMech(ToolStripItem item) {
            this.xferMechToolStripDropDownButton.Text=item.Text;
            this.xferMechToolStripDropDownButton.Tag=item.Tag;
            this._twain32.Capabilities.XferMech.Set((TwSX)item.Tag);
            this.fileFormatToolStripDropDownButton.Enabled=(TwSX)item.Tag==TwSX.File;
        }

        private void _SetFileFormat(ToolStripItem item) {
            this.fileFormatToolStripDropDownButton.Text=item.Text;
            this.fileFormatToolStripDropDownButton.Tag=item.Tag;
            this._twain32.Capabilities.ImageFileFormat.Set((TwFF)item.Tag);
        }

        private void _SetImage(Image image) {
            if(this.pictureBox1.Image!=null) {
                this.pictureBox1.Image.Dispose();
            }
            this.pictureBox1.Image=image;
        }

        private void _Upload(Image image) {
            using(var _stream=new MemoryStream()) {
                image.Save(_stream, ImageFormat.Jpeg);
                _stream.Seek(0, SeekOrigin.Begin);

                this.OnUploading(new EventArgs());
                string _name;
                this._helper.Upload(_stream,".jpg",out _name);
                this.OnUploaded(new UploadEventArgs(_name));
            }
        }

        private void _Upload(Stream stream,string ext) {
            this.OnUploading(new EventArgs());
            string _name;
            this._helper.Upload(stream, ext, out _name);
            this.OnUploaded(new UploadEventArgs(_name));
        }

        #region Twain32 events handlers

        private void _twain32_AcquireCompleted(object sender, EventArgs e) {
            try {
                
                #region Tiff-file

                if(TiffHelper.Current!=null) {
                    try {
                        TiffHelper.Current.Writer.BaseStream.Seek(0, SeekOrigin.Begin);
                        this._Upload(TiffHelper.Current.Writer.BaseStream, ".tif");

                        TiffHelper.Current.Writer.BaseStream.Seek(0, SeekOrigin.Begin);
                        this._SetImage(Image.FromStream(TiffHelper.Current.Writer.BaseStream));
                    } finally {
                        TiffHelper.Dispose();
                    }
                }

                #endregion

            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _twain32_EndXfer(object sender, Twain32.EndXferEventArgs e) {
            try {
                this._SetImage(e.Image);
                this._Upload(e.Image);
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _twain32_SetupFileXferEvent(object sender, Twain32.SetupFileXferEventArgs e) {
            try {
                e.FileName=Path.GetTempFileName();
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _twain32_FileXferEvent(object sender, Twain32.FileXferEventArgs e) {
            try {
                using(var _stream=File.OpenRead(e.ImageFileXfer.FileName)) {
                    this._Upload(_stream, string.Format(".{0}", this._twain32.Capabilities.ImageFileFormat.GetCurrent().ToString().ToLower()));
                }
                this._SetImage(Image.FromStream(new MemoryStream(File.ReadAllBytes(e.ImageFileXfer.FileName))));
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            } finally {
                try {
                    File.Delete(e.ImageFileXfer.FileName);
                } catch {
                }
            }
        }

        private void _twain32_SetupMemXferEvent(object sender, Twain32.SetupMemXferEventArgs e) {
            try {
                if(TiffHelper.Current==null) {
                    TiffHelper.Create();
                }

                #region Color Map

                if(e.ImageInfo.PixelType==TwPixelType.Palette) {
                    Twain32.ColorPalette _palette=this._twain32.Palette.Get();
                    TiffHelper.Current.ColorMap=new ushort[_palette.Colors.Length*3];
                    for(int i=0; i<_palette.Colors.Length; i++) {
                        TiffHelper.Current.ColorMap[i]=(ushort)(_palette.Colors[i].R);
                        TiffHelper.Current.ColorMap[i+_palette.Colors.Length]=(ushort)(_palette.Colors[i].G);
                        TiffHelper.Current.ColorMap[i+(_palette.Colors.Length<<1)]=(ushort)(_palette.Colors[i].B);
                    }
                }

                #endregion

            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _twain32_MemXferEvent(object sender, Twain32.MemXferEventArgs e) {
            try {
                long _bitsPerRow=e.ImageInfo.BitsPerPixel*e.ImageMemXfer.Columns;
                long _bytesPerRow=Math.Min(e.ImageMemXfer.BytesPerRow, (_bitsPerRow>>3)+((_bitsPerRow&0x07)!=0?1:0));
                using(MemoryStream _stream=new MemoryStream()) {
                    for(int i=0; i<e.ImageMemXfer.Rows; i++) {
                        _stream.Write(e.ImageMemXfer.ImageData, (int)(e.ImageMemXfer.BytesPerRow*i), (int)_bytesPerRow);
                    }
                    TiffHelper.Current.Strips.Add(TiffHelper.Current.Writer.WriteData(_stream.ToArray()));
                    TiffHelper.Current.StripByteCounts.Add((uint)_stream.Length);
                    TiffHelper.Current.RowsPerStrip.Add(e.ImageMemXfer.Rows);
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _twain32_XferDone(object sender, Twain32.XferDoneEventArgs e) {
            try {

                #region MemXfer (to tiff file)

                if(TiffHelper.Current!=null&&TiffHelper.Current.Writer!=null) {
                    Twain32.ImageInfo _info=e.GetImageInfo();
                    Collection<ITag> _tags=new Collection<ITag> {
                        Tag<uint>.Create(TiffTags.ImageWidth,(uint)_info.ImageWidth),
                        Tag<uint>.Create(TiffTags.ImageLength,(uint)_info.ImageLength),
                        Tag<ushort>.Create(TiffTags.SamplesPerPixel,(ushort)_info.BitsPerSample.Length),
                        Tag<ushort>.Create(TiffTags.BitsPerSample,new Func<short[],ushort[]>(val=>{
                            ushort[] _result=new ushort[_info.BitsPerSample.Length];
                            for(int i=0; i<_result.Length; i++) {
                                _result[i]=(ushort)_info.BitsPerSample[i];
                            }
                            return _result;
                        })(_info.BitsPerSample)),
                        Tag<TiffCompression>.Create(TiffTags.Compression,TiffCompression.NONE),
                        Tag<TiffResolutionUnit>.Create(TiffTags.ResolutionUnit,new Func<TwUnits,TiffResolutionUnit>(val=>{
                            switch(val){
                                case TwUnits.Centimeters:
                                    return TiffResolutionUnit.CENTIMETER;
                                case TwUnits.Inches:
                                    return TiffResolutionUnit.INCH;
                                default:
                                    return TiffResolutionUnit.NONE;
                            }
                        })(this._twain32.Capabilities.Units.GetCurrent())),
                        Tag<ulong>.Create(TiffTags.XResolution,(1UL<<32)|(ulong)_info.XResolution),
                        Tag<ulong>.Create(TiffTags.YResolution,(1UL<<32)|(ulong)_info.YResolution),
                        Tag<TiffHandle>.Create(TiffTags.StripOffsets,TiffHelper.Current.Strips.ToArray()),
                        Tag<uint>.Create(TiffTags.StripByteCounts,TiffHelper.Current.StripByteCounts.ToArray()),
                        Tag<uint>.Create(TiffTags.RowsPerStrip,TiffHelper.Current.RowsPerStrip.ToArray()),
                        Tag<char>.Create(TiffTags.Software,Application.ProductName.ToCharArray()),
                        Tag<char>.Create(TiffTags.Model,this._twain32.GetSourceProductName(this._twain32.SourceIndex).ToCharArray()),
                        Tag<char>.Create(TiffTags.DateTime,DateTime.Now.ToString("yyyy:MM:dd HH:mm:ss").PadRight(20,'\0').ToCharArray()),
                        Tag<char>.Create(TiffTags.HostComputer,Environment.MachineName.ToCharArray()),
                        Tag<char>.Create(TiffTags.Copyright,((AssemblyCopyrightAttribute)this.GetType().Assembly.GetCustomAttributes(typeof(AssemblyCopyrightAttribute),false)[0]).Copyright.ToCharArray())
                    };
                    switch(_info.PixelType) {
                        case TwPixelType.BW:
                            _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation, TiffPhotoMetric.BlackIsZero));
                            break;
                        case TwPixelType.Gray:
                            _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation, TiffPhotoMetric.BlackIsZero));
                            break;
                        case TwPixelType.Palette:
                            _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation, TiffPhotoMetric.Palette));
                            _tags.Add(Tag<ushort>.Create(TiffTags.ColorMap, TiffHelper.Current.ColorMap));
                            break;
                        case TwPixelType.RGB:
                            _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation, TiffPhotoMetric.RGB));
                            break;
                        default:
                            break;
                    }
                    TiffHelper.Current.Handle=TiffHelper.Current.Writer.WriteImageFileDirectory(TiffHelper.Current.Handle, _tags);
                }

                #endregion

            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _twain32_AcquireError(object sender, Twain32.AcquireErrorEventArgs e) {
            try {
                this.OnError(new Saraff.Twain.WebSample.Core.ErrorEventArgs(string.Format("{4}{0}: {1} ConditionCode = {2}; ReturnCode = {3};{4}", e.Exception.GetType().Name, e.Exception.Message, e.Exception.ConditionCode, e.Exception.ReturnCode, Environment.NewLine)));
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Toolbar events handlers

        private void newToolStripButton_Click(object sender, EventArgs e) {
            try {
                this._twain32.Acquire();
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void saveToolStripButton_Click(object sender, EventArgs e) {
            try {
                if(this.saveFileDialog.ShowDialog()==DialogResult.OK) {
                    this.pictureBox1.Image.Save(this.saveFileDialog.FileName);
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataSourceToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                this._LoadDS();
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _ResolutionItemSelected(object sender, EventArgs e) {
            try {
                ToolStripItem _item=sender as ToolStripItem;
                if(_item!=null) {
                    this._SetResolution(_item);
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _PixelTypeItemSelected(object sender, EventArgs e) {
            try {
                ToolStripItem _item=sender as ToolStripItem;
                if(_item!=null) {
                    this._SetPixelType(_item);
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _XferMechItemSelected(object sender, EventArgs e) {
            try {
                ToolStripItem _item=sender as ToolStripItem;
                if(_item!=null) {
                    this._SetXferMech(_item);
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void _FileFormatSelected(object sender, EventArgs e) {
            try {
                ToolStripItem _item=sender as ToolStripItem;
                if(_item!=null) {
                    this._SetFileFormat(_item);
                }
            } catch(Exception ex) {
                MessageBox.Show(string.Format("{1}{0}{2}", Environment.NewLine, ex.Message, ex.StackTrace), ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Private Events Handlers

        private void OnUploading(EventArgs e) {
            if(this.Uploading!=null) {
                this.Uploading(this, e);
            }
        }

        private void OnUploaded(UploadEventArgs e) {
            if(this.Uploaded!=null) {
                this.Uploaded(this, e);
            }
        }

        private void OnError(Saraff.Twain.WebSample.Core.ErrorEventArgs e) {
            if(this.Error!=null) {
                this.Error(this, e);
            }
        }

        #endregion

        #region Events

        [ApplicationProcessed]
        public event EventHandler Uploading;

        [ApplicationProcessed]
        public event EventHandler Uploaded;

        [ApplicationProcessed]
        public event EventHandler Error;

        #endregion

        private sealed class TiffHelper {

            public static void Create() {
                TiffHelper.Current=new TiffHelper {
                    Writer=TiffWriter.Create(new MemoryStream()),
                    Strips=new List<TiffHandle>(),
                    StripByteCounts=new List<uint>(),
                    RowsPerStrip=new List<uint>()
                };
                TiffHelper.Current.Handle=TiffHelper.Current.Writer.WriteHeader();
            }

            public static void Dispose() {
                if(TiffHelper.Current!=null) {
                    TiffHelper.Current=null;
                }
            }

            public static TiffHelper Current {
                get;
                private set;
            }

            public TiffHandle Handle {
                get;
                set;
            }

            public TiffWriter Writer {
                get;
                private set;
            }

            public List<TiffHandle> Strips {
                get;
                private set;
            }

            public List<uint> StripByteCounts {
                get;
                private set;
            }

            public List<uint> RowsPerStrip {
                get;
                private set;
            }

            public ushort[] ColorMap {
                get;
                set;
            }
        }

        private delegate TResult Func<T, TResult>(T arg);
    }
}
