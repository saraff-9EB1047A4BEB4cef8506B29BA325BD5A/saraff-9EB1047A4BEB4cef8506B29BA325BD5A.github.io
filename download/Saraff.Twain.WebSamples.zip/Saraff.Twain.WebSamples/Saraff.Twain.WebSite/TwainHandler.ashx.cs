﻿/* Этот файл является частью примеров использования библиотек Saraff.Twain.NET и Saraff.AxHost.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Web;
using System.Net;
using System.IO;
using System.Text;
using System.Web.Hosting;

namespace Saraff.Twain.WebSite {

    public class TwainHandler:IHttpHandler {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <remarks>
        /// Request format:
        ///     action: byte {1: CREATE; 2: APPEND;}
        ///     data-length: int
        ///     data: byte[data-length]
        ///     
        /// Response format:
        ///     result: byte {0x00: OK; 0xff: Exception;}
        ///     data-length: int
        ///     data: byte[data-length]
        /// </remarks>
        public void ProcessRequest(HttpContext context) {
            try {
                using(var _reader=new BinaryReader(context.Request.InputStream)) {
                    switch((QueryCode)_reader.ReadByte()) {
                        case QueryCode.Create:
                            this._WriteResponse(context, ResultCode.OK, this._Create(Encoding.UTF8.GetString(_reader.ReadBytes(_reader.ReadInt32()))));
                            break;
                        case QueryCode.Append:
                            var _data=_reader.ReadBytes(_reader.ReadInt32()); // {[name length: byte][name][image data]}
                            this._Append(Encoding.UTF8.GetString(_data, 1, _data[0]), _data, _data[0]+1, _data.Length-_data[0]-1);
                            this._WriteResponse(context, ResultCode.OK, new byte[0]);
                            break;
                        default:
                            throw new InvalidOperationException();
                    }
                }
            } catch(Exception ex) {
                this._WriteResponse(context, ResultCode.Exception, string.Format("{0}: {1}\n{2}", ex.GetType().Name, ex.Message, ex.StackTrace));
            }
        }

        public bool IsReusable {
            get {
                return false;
            }
        }

        private string _Create(string ext) {
            return Path.GetFileName(Path.ChangeExtension(Path.GetTempFileName(),ext));
        }

        private void _Append(string name,byte[] data,int offset,int count) {
            using(var _stream=File.Open(Path.Combine(HostingEnvironment.MapPath("~/App_Data"), name), FileMode.Append)) {
                _stream.Write(data, offset, count);
            }
        }

        private void _WriteResponse(HttpContext context, ResultCode result, string data) {
            this._WriteResponse(context, result, Encoding.UTF8.GetBytes(data));
        }

        private void _WriteResponse(HttpContext context,ResultCode result,byte[] data) {
            context.Response.ContentType="application/octet-stream";
            using(var _writer=new BinaryWriter(context.Response.OutputStream)) {
                _writer.Write((byte)result);
                _writer.Write(data.Length);
                _writer.Write(data);
            }
        }

        private enum ResultCode:byte {
            OK=0x00,
            Exception=0xff
        }

        private enum QueryCode:byte {
            Create=1,
            Append=2
        }
    }
}