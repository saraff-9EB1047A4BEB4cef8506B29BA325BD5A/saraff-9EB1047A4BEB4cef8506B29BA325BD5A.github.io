﻿/* Этот файл является частью примеров использования библиотеки Saraff.TwainX.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.TwainX.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.TwainX.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.TwainX.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.TwainX.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.TwainX.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.TwainX.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.IO;
using System.Reflection;
using Saraff.TwainX;
using _IoC = Saraff.IoC;

[assembly: _IoC.BindService(typeof(IImageFactory<FileStream>), typeof(Saraff.TwainX.NETCoreSample1.Core._ImageFactoryComponent))]

namespace Saraff.TwainX.NETCoreSample1 {

    internal sealed class Program {

        [STAThread]
        private static void Main(string[] args) {
            try {
                using (var _container = new _IoC.ServiceContainer()) {
                    _container.Load(typeof(Program).Assembly);
                    var _provider = _container as IServiceProvider;

                    var _twainx = _container.CreateInstance<TwainX>();
                    var _asm = _twainx.GetType().Assembly;
                    Console.WriteLine(
                        "{1} {2}{0}{3}{0}",
                        Environment.NewLine,
                        ((AssemblyTitleAttribute)_asm.GetCustomAttributes(typeof(AssemblyTitleAttribute), false)[0]).Title,
                        ((AssemblyFileVersionAttribute)_asm.GetCustomAttributes(typeof(AssemblyFileVersionAttribute), false)[0]).Version,
                        ((AssemblyCopyrightAttribute)_asm.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false)[0]).Copyright);

                    #region ShowUI

                    Console.Write("ShowUI {0}: ", _twainx.ShowUI ? "[Y/n]" : "[y/N]");
                    for (var _res = Console.ReadLine().Trim().ToUpper(); !string.IsNullOrEmpty(_res);) {
                        _twainx.ShowUI = _res == "Y";
                        break;
                    }
                    Console.WriteLine("ShowUI = {0}", _twainx.ShowUI ? "Y" : "N");

                    #endregion

                    _twainx.OpenDSM();

                    #region Select Data Source

                    Console.WriteLine();
                    Console.WriteLine("Select Data Source:");
                    for (var i = 0; i < _twainx.SourcesCount; i++) {
                        Console.WriteLine("{0}: {1}{2}", i, _twainx.GetSourceProductName(i), _twainx.GetIsSourceTwain2Compatible(i) ? " (TWAIN 2.x)" : string.Empty);
                    }
                    Console.Write("[{0}]: ", _twainx.SourceIndex);
                    for (var _res = Console.ReadLine().Trim(); !string.IsNullOrEmpty(_res);) {
                        _twainx.SourceIndex = Convert.ToInt32(_res);
                        break;
                    }
                    Console.WriteLine(string.Format("Data Source: {0}", _twainx.GetSourceProductName(_twainx.SourceIndex)));

                    #endregion

                    _twainx.OpenDataSource();

                    if (!_twainx.ShowUI) {

                        #region Select Resolution

                        Console.WriteLine();
                        Console.WriteLine("Select Resolution:");
                        var _resolutions = _twainx.Capabilities.XResolution.Get();
                        for (var i = 0; i < _resolutions.Count; i++) {
                            Console.WriteLine("{0}: {1} dpi", i, _resolutions[i]);
                        }
                        Console.Write("[{0}]: ", _resolutions.CurrentIndex);
                        for (var _res = Console.ReadLine().Trim(); !string.IsNullOrEmpty(_res);) {
                            var _val = (float)_resolutions[Convert.ToInt32(_res)];
                            _twainx.Capabilities.XResolution.Set(_val);
                            _twainx.Capabilities.YResolution.Set(_val);
                            break;
                        }
                        Console.WriteLine(string.Format("Resolution: {0}", _twainx.Capabilities.XResolution.GetCurrent()));

                        #endregion

                        #region Select Pixel Type

                        Console.WriteLine();
                        Console.WriteLine("Select Pixel Type:");
                        var _pixels = _twainx.Capabilities.PixelType.Get();
                        for (var i = 0; i < _pixels.Count; i++) {
                            Console.WriteLine("{0}: {1}", i, _pixels[i]);
                        }
                        Console.Write("[{0}]: ", _pixels.CurrentIndex);
                        for (var _res = Console.ReadLine().Trim(); !string.IsNullOrEmpty(_res);) {
                            var _val = (TwPixelType)_pixels[Convert.ToInt32(_res)];
                            _twainx.Capabilities.PixelType.Set(_val);
                            break;
                        }
                        Console.WriteLine(string.Format("Pixel Type: {0}", _twainx.Capabilities.PixelType.GetCurrent()));

                        #endregion

                    }

                    _twainx.EndXfer += (sender, e) => {
                        try {
                            using (var _stream = e.CreateImage(_provider.GetService(typeof(IImageFactory<FileStream>)) as IImageFactory<FileStream>)) {
                                Console.WriteLine();
                                Console.WriteLine($"{Math.Round(_stream.Length / (1024f * 1024f), 2)}Mb written to \"{_stream.Name}\"");
                            }
                        } catch (Exception ex) {
                            Console.WriteLine("{0}: {1}{2}{3}{2}", ex.GetType().Name, ex.Message, Environment.NewLine, ex.StackTrace);
                        }
                    };

                    _twainx.AcquireCompleted += (sender, e) => {
                        try {
                            Console.WriteLine();
                            Console.WriteLine("Acquire Completed.");
                        } catch (Exception ex) {
                            Program.WriteException(ex);
                        }
                    };

                    _twainx.AcquireError += (sender, e) => {
                        try {
                            Console.WriteLine();
                            Console.WriteLine("Acquire Error: ReturnCode = {0}; ConditionCode = {1};", e.Exception.ReturnCode, e.Exception.ConditionCode);
                            Program.WriteException(e.Exception);
                        } catch (Exception ex) {
                            Program.WriteException(ex);
                        }
                    };

                    _twainx.Acquire();
                }
            } catch (Exception ex) {
                Program.WriteException(ex);
            }
        }

        private static void WriteException(Exception ex) {
            for (var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Console.WriteLine("{0}: {1}{2}{3}{2}", _ex.GetType().Name, _ex.Message, Environment.NewLine, _ex.StackTrace);
            }
        }
    }
}
