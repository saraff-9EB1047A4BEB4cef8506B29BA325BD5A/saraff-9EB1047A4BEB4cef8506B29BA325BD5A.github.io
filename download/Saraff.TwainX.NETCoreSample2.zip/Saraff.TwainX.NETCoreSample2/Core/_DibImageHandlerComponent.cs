﻿/* Этот файл является частью примеров использования библиотеки Saraff.TwainX.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.TwainX.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.TwainX.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.TwainX.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.TwainX.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.TwainX.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.TwainX.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Saraff.TwainX.NETCoreSample2.Core {

    internal sealed class _DibImageHandlerComponent : Component, IImageHandler {
        private const int BufferSize = 256 * 1024;

        #region IImageHandler

        public Stream PtrToStream(IntPtr ptr, IStreamProvider provider) {
            var _stream = provider?.GetStream() ?? new MemoryStream();
            var _writer = new BinaryWriter(_stream);

            int _size = _DibImageHandlerComponent.GlobalSize(_DibImageHandlerComponent.GlobalHandle(ptr));

            #region Write BITMAPFILEHEADER to stream

            BITMAPINFOHEADER _header = Marshal.PtrToStructure(ptr, typeof(BITMAPINFOHEADER)) as BITMAPINFOHEADER;

            _writer.Write((ushort)0x4d42);
            _writer.Write(14 + _size);
            _writer.Write(0);
            _writer.Write(14 + _header.biSize + (_header.ClrUsed << 2));

            #endregion

            byte[] _buffer = new byte[_DibImageHandlerComponent.BufferSize];

            #region  Copy data to stream

            for (int _offset = 0, _len = 0; _offset < _size; _offset += _len) {
                _len = Math.Min(_DibImageHandlerComponent.BufferSize, _size - _offset);
                Marshal.Copy((IntPtr)(ptr.ToInt64() + _offset), _buffer, 0, _len);
                _writer.Write(_buffer, 0, _len);
            }

            #endregion

            return _stream;
        }

        #endregion

        [DllImport("kernel32.dll")]
        private static extern IntPtr GlobalHandle(IntPtr pMem);

        [DllImport("kernel32.dll")]
        private static extern int GlobalSize(IntPtr hMem);

        [StructLayout(LayoutKind.Sequential, Pack = 2)]
        private class BITMAPINFOHEADER {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;

            public int ClrUsed {
                get {
                    return this.IsRequiredCreateColorTable ? 1 << this.biBitCount : this.biClrUsed;
                }
            }

            public bool IsRequiredCreateColorTable {
                get {
                    return this.biClrUsed == 0 && this.biBitCount <= 8;
                }
            }
        }
    }
}
