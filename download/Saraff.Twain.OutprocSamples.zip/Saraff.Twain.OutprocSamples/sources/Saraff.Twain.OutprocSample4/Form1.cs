﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2016.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2016.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Saraff.Twain.Aux;

namespace Saraff.Twain.OutprocSample4 {

    public sealed partial class Form1:Form {
        private const string _x86Aux = "Saraff.Twain.Aux_x86.exe";
        private const string _msilAux = "Saraff.Twain.Aux_MSIL.exe";

        public Form1() {
            InitializeComponent();
            ((ComboBox)this.toolStripComboBox1.Control).DataSource=this.dsBindingSource;
        }

        protected async override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            try {
                await this._Load();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private async Task _Load() {
            this.toolStrip1.Enabled=false;
            this.Text=string.Format("{0} - Loading...",this.Name);
            this.dsBindingSource.DataSource=new string[] { "Loading..." };
            this.resolutionsToolStripDropDownButton.Text="Loading...";
            this.pixelTypesToolStripDropDownButton.Text="Loading...";
            this.xferModesToolStripDropDownButton.Text="Loading...";
            this.imageFormatsToolStripDropDownButton.Text="Loading...";

            var _result = new Collection<DS>();
            var _index = 0;
            await Task.Run(() => {
                TwainExternalProcess.Execute(
                   Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),Form1._x86Aux),
                   twain => {
                       try {
                           for(var i = 0; i<twain.SourcesCount; i++) {
                               _result.Add(new DS {
                                   Id=i,
                                   Identity=twain.GetSourceIdentity(i),
                                   IsX86=true,
                                   IsTwain2=twain.IsTwain2Supported
                               });
                           }
                           _index=twain.SourceIndex;
                       }catch(Exception ex) {
                           this._ShowError(ex);
                       }
                   });
                TwainExternalProcess.Execute(
                    Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),Form1._msilAux),
                    twain => {
                        try {
                            if(!Environment.Is64BitOperatingSystem&&!twain.IsTwain2Supported) {
                                return;
                            }
                            for(var i = 0; i<twain.SourcesCount; i++) {
                                _result.Add(new DS {
                                    Id=i,
                                    Identity=twain.GetSourceIdentity(i),
                                    IsX86=!Environment.Is64BitOperatingSystem,
                                    IsTwain2=twain.IsTwain2Supported
                                });
                            }
                        }catch(Exception ex) {
                            this._ShowError(ex);
                        }
                    });
            });

            this.dsBindingSource.DataSource=_result;
            this.dsBindingSource.Position=_index;
            await this._LoadCaps();
            this.dsBindingSource.CurrentChanged+=this.dsBindingSource_CurrentChanged;
        }

        private async Task _LoadCaps() {
            var _ds = this.dsBindingSource.Current as DS;
            if(_ds!=null) {
                this.Text=string.Format("{0} - Loading Capabilities...",this.Name);
                this.toolStrip1.Enabled=false;
                this.resolutionsToolStripDropDownButton.Text="Loading...";
                this.pixelTypesToolStripDropDownButton.Text="Loading...";
                this.xferModesToolStripDropDownButton.Text="Loading...";
                this.imageFormatsToolStripDropDownButton.Text="Loading...";

                Twain32.Enumeration _resolutions = null, _pixelTypes = null, _xferModes = null, _imageFormates = null;
                await Task.Run(() => {
                    TwainExternalProcess.Execute(
                        Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),_ds.IsX86&&!_ds.IsTwain2 ? Form1._x86Aux : Form1._msilAux),
                        twain => {
                            try {
                                twain.SourceIndex=_ds.Id;
                                twain.OpenDataSource();

                                _resolutions=twain.Capabilities.XResolution.Get();
                                _pixelTypes=twain.Capabilities.PixelType.Get();
                                _xferModes=twain.Capabilities.XferMech.Get();
                                if((twain.Capabilities.ImageFileFormat.IsSupported()&TwQC.Get)!=0) {
                                    _imageFormates=twain.Capabilities.ImageFileFormat.Get();
                                }
                            }catch(Exception ex) {
                                this._ShowError(ex);
                            }
                        }
                    );
                });

                this._Fill(this.resolutionsToolStripDropDownButton,_resolutions);
                this._Fill(this.pixelTypesToolStripDropDownButton,_pixelTypes);
                this._Fill(xferModesToolStripDropDownButton,_xferModes);
                this._Fill(this.imageFormatsToolStripDropDownButton,_imageFormates);
                this.Text=this.Name;
                this.toolStrip1.Enabled=true;
            }
        }

        private void _Fill(ToolStripDropDownButton control,Twain32.Enumeration items) {
            if(!(control.Visible=items!=null&&items.Count>0)) {
                return;
            }
            control.DropDownItems.Clear();
            for(var i = 0; i<items.Count; i++) {
                control.DropDownItems.Add(
                    items[i].ToString(),
                    null,
                    (sender,e) => {
                        var _sender = sender as ToolStripItem;
                        if(_sender!=null) {
                            _sender.OwnerItem.Tag=_sender.Tag;
                            _sender.OwnerItem.Text=_sender.Text;
                        }
                    }).Tag=items[i];
            }
            control.Tag=items[items.CurrentIndex];
            control.Text=items[items.CurrentIndex].ToString();
        }

        private async Task _Acquire() {
            var _ds = this.dsBindingSource.Current as DS;
            if(_ds!=null) {
                this.Text=string.Format("{0} - Acquiring...",this.Name);
                this.toolStrip1.Enabled=false;
                var _resolution = (float)this.resolutionsToolStripDropDownButton.Tag;
                var _pixelType = (TwPixelType)this.pixelTypesToolStripDropDownButton.Tag;
                var _xferMode = (TwSX)this.xferModesToolStripDropDownButton.Tag;
                var _imageFormat = (TwFF)(this.imageFormatsToolStripDropDownButton.Tag??TwFF.Bmp);

                await Task.Run(() => {
                    TwainExternalProcess.Execute(
                        Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),_ds.IsX86&&!_ds.IsTwain2 ? Form1._x86Aux : Form1._msilAux),
                        twain => {
                            try {
                                #region EndXfer

                                twain.EndXfer+=(sender,e) => {
                                    try {
                                        this.Invoke(new Action(() => {
                                            try {
                                                this.CurrentImage=e.Image;
                                            } catch(Exception ex) {
                                                this._ShowError(ex);
                                            }
                                        }));
                                    } catch(Exception ex) {
                                        this._ShowError(ex);
                                    }
                                };

                                #endregion

                                #region SetupMemXferEvent

                                twain.SetupMemXferEvent+=(sender,e) => {
                                    try {
                                        Bitmap _image = null;
                                        switch(e.ImageInfo.PixelType) {
                                            case TwPixelType.BW:
                                                _image=new Bitmap(e.ImageInfo.ImageWidth,e.ImageInfo.ImageLength,PixelFormat.Format1bppIndexed);
                                                break;
                                            case TwPixelType.Gray:
                                            case TwPixelType.Palette:
                                                _image=new Bitmap(e.ImageInfo.ImageWidth,e.ImageInfo.ImageLength,e.ImageInfo.BitsPerPixel==4 ? PixelFormat.Format4bppIndexed : PixelFormat.Format8bppIndexed);
                                                Color[] _src = null;
                                                try {
                                                    _src = twain.Palette.Get().Colors;
                                                } catch(TwainException) {
                                                    _src = new Color[1<<e.ImageInfo.BitsPerPixel];
                                                    for(int i = 0, _step = 256>>e.ImageInfo.BitsPerPixel; i<_src.Length; i++) {
                                                        var _val = i*_step;
                                                        _src[i]=Color.FromArgb(_val,_val,_val);
                                                    }
                                                }
                                                var _dest = _image.Palette;
                                                for(var i = 0; i<_src.Length; i++) {
                                                    _dest.Entries[i]=_src[i];
                                                }
                                                typeof(Image).GetProperty("Palette").SetValue(_image,_dest,BindingFlags.Instance|BindingFlags.NonPublic,null,null,null);
                                                break;
                                            case TwPixelType.RGB:
                                                _image=new Bitmap(
                                                    e.ImageInfo.ImageWidth,
                                                    e.ImageInfo.ImageLength,
                                                    new Dictionary<int,PixelFormat> {
                                                        {8,PixelFormat.Format24bppRgb},
                                                        {16,PixelFormat.Format48bppRgb},
                                                        {24,PixelFormat.Format24bppRgb},
                                                        {48,PixelFormat.Format48bppRgb}
                                                    }[e.ImageInfo.BitsPerPixel]);
                                                break;
                                        }
                                        this.Invoke(new Action(() => {
                                            try {
                                                this.CurrentImage=_image;
                                            } catch(Exception ex) {
                                                this._ShowError(ex);
                                            }
                                        }));
                                    } catch(Exception ex) {
                                        this._ShowError(ex);
                                    }
                                };

                                #endregion

                                #region MemXferEvent

                                var _time = DateTime.Now;
                                twain.MemXferEvent+=(sender,e) => {
                                    try {
                                        this.Invoke(new Action(() => {
                                            try {
                                                if(e.ImageInfo.PixelType==TwPixelType.RGB) {
                                                    using(var _stream = new MemoryStream(e.ImageMemXfer.ImageData)) {
                                                        var _reader = new BinaryReader(_stream);
                                                        var _writer = new BinaryWriter(_stream);
                                                        for(var _row = 0; _row<e.ImageMemXfer.Rows; _row++, _stream.Seek(e.ImageMemXfer.BytesPerRow*_row,SeekOrigin.Begin)) {
                                                            for(var _pixel = 0; _pixel<e.ImageMemXfer.Columns; _pixel++) {
                                                                var _buf = 0UL;
                                                                var _bytesPerPixel = e.ImageInfo.BitsPerPixel>>3;
                                                                for(var i = 0; i<_bytesPerPixel; i++) {
                                                                    _buf|=(ulong)_reader.ReadByte()<<(i<<3);
                                                                }
                                                                _stream.Seek(-_bytesPerPixel,SeekOrigin.Current);
                                                                _buf=this._PixelTransform(_buf,e.ImageInfo);
                                                                for(var i = 0; i<_bytesPerPixel; i++) {
                                                                    _writer.Write((byte)((_buf>>(i<<3))&0xff));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                var _bitmapData = ((Bitmap)this.CurrentImage).LockBits(new Rectangle((int)e.ImageMemXfer.XOffset,(int)e.ImageMemXfer.YOffset,(int)e.ImageMemXfer.Columns,(int)e.ImageMemXfer.Rows),ImageLockMode.ReadWrite,this.CurrentImage.PixelFormat);
                                                try {
                                                    for(var i = 0; i<e.ImageMemXfer.Rows; i++) {
                                                        Marshal.Copy(
                                                            e.ImageMemXfer.ImageData,
                                                            (int)e.ImageMemXfer.BytesPerRow*i,
                                                            _bitmapData.Scan0+((int)e.ImageMemXfer.BytesPerRow*i),
                                                            (int)e.ImageMemXfer.BytesPerRow);
                                                    }
                                                } finally {
                                                    ((Bitmap)this.CurrentImage).UnlockBits(_bitmapData);
                                                }
                                                if((DateTime.Now-_time).TotalSeconds>0.2f) {
                                                    this.pictureBox1.Refresh();
                                                    _time=DateTime.Now;
                                                }
                                            } catch(Exception ex) {
                                                this._ShowError(ex);
                                            }
                                        }));
                                    } catch(Exception ex) {
                                        this._ShowError(ex);
                                    }
                                };

                                #endregion

                                #region SetupFileXferEvent

                                twain.SetupFileXferEvent+=(sender,e) => {
                                    try {
                                        this.Invoke(new Action(() => {
                                            try {
                                                this.saveFileDialog1.Filter=string.Format("{0}-files|*.{0}",_imageFormat.ToString().ToLower());
                                                this.saveFileDialog1.DefaultExt=_imageFormat.ToString().ToLower();
                                                if(this.saveFileDialog1.ShowDialog()==DialogResult.OK) {
                                                    e.FileName=this.saveFileDialog1.FileName;
                                                } else {
                                                    e.Cancel=true;
                                                }
                                            } catch(Exception ex) {
                                                this._ShowError(ex);
                                            }
                                        }));
                                    } catch(Exception ex) {
                                        this._ShowError(ex);
                                    }
                                };

                                #endregion

                                #region FileXferEvent

                                twain.FileXferEvent+=(sender,e) => {
                                    try {
                                        this.Invoke(new Action(() => {
                                            try {
                                                this.CurrentImage=Image.FromFile(e.ImageFileXfer.FileName);
                                            } catch(Exception ex) {
                                                this._ShowError(ex);
                                            }
                                        }));
                                    } catch(Exception ex) {
                                        this._ShowError(ex);
                                    }
                                };

                                #endregion

                                #region AcquireError

                                twain.AcquireError+=(sender,e) => {
                                    this._ShowError(e.Exception);
                                };

                                #endregion

                                #region AcquireCompleted

                                twain.AcquireCompleted+=(sender,e) => {
                                    try {
                                        this.Invoke(new Action(() => this.pictureBox1.Refresh()));
                                    }catch(Exception ex) {
                                        this._ShowError(ex);
                                    }
                                };

                                #endregion

                                twain.SourceIndex=_ds.Id;
                                twain.OpenDataSource();

                                twain.Capabilities.XferCount.Set(1);
                                twain.Capabilities.Indicators.Set(false);
                                twain.Capabilities.XResolution.Set(_resolution);
                                twain.Capabilities.YResolution.Set(_resolution);
                                twain.Capabilities.PixelType.Set(_pixelType);
                                twain.Capabilities.XferMech.Set(_xferMode);
                                if(_xferMode==TwSX.File&&(twain.Capabilities.ImageFileFormat.IsSupported()&TwQC.Set)!=0) {
                                    twain.Capabilities.ImageFileFormat.Set(_imageFormat);
                                }

                                twain.Acquire();
                            } catch(Exception ex) {
                                this._ShowError(ex);
                            }
                        });
                });
                this.Text=this.Name;
                this.toolStrip1.Enabled=true;
            }
        }

        private void _Save() {
            this.saveFileDialog1.Filter="jpg-files|*.jpg";
            this.saveFileDialog1.DefaultExt="jpg";
            if(this.CurrentImage!=null&&this.saveFileDialog1.ShowDialog()==DialogResult.OK) {
                this.CurrentImage.Save(this.saveFileDialog1.FileName,ImageFormat.Jpeg);
            }
        }

        private void _ShowError(Exception ex) {
            var _action = new Action(() => MessageBox.Show(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error));
            if(this.InvokeRequired) {
                this.Invoke(_action);
            } else {
                _action();
            }
        }

        private ulong _PixelTransform(ulong pixel,Twain32.ImageInfo info) {
            var _sumBitsPerSample = info.BitsPerSample[0]*info.BitsPerSample.Length;
            var _result = pixel&(0xffffffffffffffff<<_sumBitsPerSample);
            pixel<<=info.BitsPerPixel-_sumBitsPerSample;
            for(var i = 0; i<info.BitsPerSample.Length; i++) {
                _result>>=info.BitsPerSample[0];
                _result|=pixel&(((1UL<<info.BitsPerSample[0])-1)<<info.BitsPerPixel-info.BitsPerSample[0]);
                pixel<<=info.BitsPerSample[0];
            }
            return _result;
        }

        private Image CurrentImage {
            get {
                return this.pictureBox1.Image;
            }
            set {
                if(this.pictureBox1.Image!=null) {
                    this.pictureBox1.Image.Dispose();
                    this.pictureBox1.Image=null;
                }
                this.pictureBox1.Image=value;
            }
        }

        private async void newToolStripButton_Click(object sender,EventArgs e) {
            try {
                await this._Acquire();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void saveToolStripButton_Click(object sender,EventArgs e) {
            try {
                this._Save();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private async void dsBindingSource_CurrentChanged(object sender,EventArgs e) {
            try {
                await this._LoadCaps();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void xferModesToolStripDropDownButton_TextChanged(object sender,EventArgs e) {
            try {
                if(this.xferModesToolStripDropDownButton.Tag!=null) {
                    this.imageFormatsToolStripDropDownButton.Enabled=(TwSX)this.xferModesToolStripDropDownButton.Tag==TwSX.File;
                }
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }
    }

    public sealed class DS {

        public int Id {
            get;
            set;
        }

        public Twain32.Identity Identity {
            get;
            set;
        }

        public bool IsX86 {
            get;
            set;
        }

        public bool IsTwain2 {
            get;
            set;
        }

        public override string ToString() {
            return string.Format("[{0}, {1}] {2}",this.IsTwain2 ? "2.x" : "1.x",this.IsX86 ? "x86_32" : "x86_64",this.Identity.Name);
        }
    }
}
