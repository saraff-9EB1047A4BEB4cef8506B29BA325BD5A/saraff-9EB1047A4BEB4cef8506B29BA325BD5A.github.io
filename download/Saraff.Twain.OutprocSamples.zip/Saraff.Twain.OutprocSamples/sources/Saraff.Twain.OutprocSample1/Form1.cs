﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2016.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2016.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Saraff.Twain.Aux;

namespace Saraff.Twain.OutprocSample1 {

    public sealed partial class Form1:Form {
        private const string _x86Aux = "Saraff.Twain.Aux_x86.exe";
        private const string _msilAux = "Saraff.Twain.Aux_MSIL.exe";

        public Form1() {
            InitializeComponent();
            ((ComboBox)this.toolStripComboBox1.Control).DataSource=this.dsBindingSource;
        }

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            try {
                this._Load();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void _Load() {
            var _result = new Collection<DS>();
            var _index = 0;
            TwainExternalProcess.Execute(
                Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),Form1._x86Aux),
                twain => {
                    for(var i = 0; i<twain.SourcesCount; i++) {
                        _result.Add(new DS {
                            Id=i,
                            Identity=twain.GetSourceIdentity(i),
                            IsX86=true,
                            IsTwain2=twain.IsTwain2Supported
                        });
                    }
                    _index=twain.SourceIndex;
                });
            TwainExternalProcess.Execute(
                Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),Form1._msilAux),
                twain => {
                    if(!Environment.Is64BitOperatingSystem&&!twain.IsTwain2Supported) {
                        return;
                    }
                    for(var i = 0; i<twain.SourcesCount; i++) {
                        _result.Add(new DS {
                            Id=i,
                            Identity=twain.GetSourceIdentity(i),
                            IsX86=!Environment.Is64BitOperatingSystem,
                            IsTwain2=twain.IsTwain2Supported
                        });
                    }
                });

            this.dsBindingSource.DataSource=_result;
            this.dsBindingSource.Position=_index;
        }

        private void _Acquire() {
            var _ds = this.dsBindingSource.Current as DS;
            if(_ds!=null) {
                Image _image = null;
                TwainExternalProcess.Execute(
                    Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),_ds.IsX86&&!_ds.IsTwain2 ? Form1._x86Aux : Form1._msilAux),
                    twain => {
                        twain.EndXfer+=(sender,e) => {
                            try {
                                var _stream = new MemoryStream();
                                e.Image.Save(_stream,ImageFormat.Bmp);
                                _stream.Seek(0,SeekOrigin.Begin);
                                _image=Image.FromStream(_stream);
                            } catch(Exception ex) {
                                this._ShowError(ex);
                            }
                        };
                        twain.AcquireError+=(sender,e) => {
                            this._ShowError(e.Exception);
                        };
                        twain.SourceIndex=_ds.Id;
                        twain.OpenDataSource();

                        twain.Capabilities.XferCount.Set(1);
                        twain.Capabilities.Indicators.Set(false);

                        twain.Acquire();
                    });
                if(this.pictureBox1.Image!=null) {
                    this.pictureBox1.Image.Dispose();
                    this.pictureBox1.Image=null;
                }
                this.pictureBox1.Image=_image;
            }
        }

        private void _Save() {
            if(this.pictureBox1.Image!=null&&this.saveFileDialog1.ShowDialog()==DialogResult.OK) {
                this.pictureBox1.Image.Save(this.saveFileDialog1.FileName,ImageFormat.Jpeg);
            }
        }

        private void _ShowError(Exception ex) {
            MessageBox.Show(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
        }

        private void newToolStripButton_Click(object sender,EventArgs e) {
            try {
                this._Acquire();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void saveToolStripButton_Click(object sender,EventArgs e) {
            try {
                this._Save();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }
    }

    public sealed class DS {

        public int Id {
            get;
            set;
        }

        public Twain32.Identity Identity {
            get;
            set;
        }

        public bool IsX86 {
            get;
            set;
        }

        public bool IsTwain2 {
            get;
            set;
        }

        public override string ToString() {
            return string.Format("[{0}, {1}] {2}",this.IsTwain2 ? "2.x" : "1.x",this.IsX86 ? "x86_32" : "x86_64",this.Identity.Name);
        }
    }
}
