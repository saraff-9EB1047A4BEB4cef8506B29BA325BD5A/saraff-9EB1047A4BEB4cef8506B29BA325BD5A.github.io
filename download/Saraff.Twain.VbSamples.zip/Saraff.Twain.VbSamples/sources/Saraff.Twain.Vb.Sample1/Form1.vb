﻿Public Class Form1

    Private Sub _twain32_AcquireCompleted(sender As System.Object, e As System.EventArgs) Handles _twain32.AcquireCompleted
        Try
            If Not Me.PictureBox1.Image Is Nothing Then
                Me.PictureBox1.Image.Dispose()
            End If
            Me.PictureBox1.Image = Me._twain32.GetImage(0)
        Catch ex As Exception
            MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub selectButton_Click(sender As System.Object, e As System.EventArgs) Handles selectButton.Click
        Try
            Me._twain32.SelectSource()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub scanButton_Click(sender As System.Object, e As System.EventArgs) Handles scanButton.Click
        Try
            Me._twain32.Acquire()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class
