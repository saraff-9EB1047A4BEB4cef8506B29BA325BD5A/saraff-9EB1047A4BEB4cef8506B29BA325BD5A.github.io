﻿Public Class Form1

    Protected Overrides Sub OnLoad(e As System.EventArgs)
        MyBase.OnLoad(e)
        Try
            Me._twain32.OpenDSM()

            'Fill list of data sorces
            Me.dataSourcesToolStripComboBox.Items.Clear()
            For i = 0 To Me._twain32.SourcesCount - 1 Step 1
                Me.dataSourcesToolStripComboBox.Items.Add(Me._twain32.GetSourceProductName(i))
            Next
            If Me._twain32.SourcesCount > 0 Then
                Me.dataSourcesToolStripComboBox.SelectedIndex = Me._twain32.SourceIndex
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub _SetImage(image As Image)
        If Not Me.PictureBox1.Image Is Nothing Then
            Me.PictureBox1.Image.Dispose()
        End If
        Me.PictureBox1.Image = image
    End Sub

#Region "Twain32 events handlers"

    Private Sub _twain32_AcquireCompleted(sender As System.Object, e As System.EventArgs) Handles _twain32.AcquireCompleted
        Try
            If Me._twain32.ImageCount > 0 Then
                Me._SetImage(Me._twain32.GetImage(0))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "Toolbar Events Handlers"

    Private Sub dataSourcesToolStripComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles dataSourcesToolStripComboBox.SelectedIndexChanged
        Try
            Me._twain32.CloseDataSource()
            Me._twain32.SourceIndex = Me.dataSourcesToolStripComboBox.SelectedIndex
            Me._twain32.OpenDataSource()

            'Get dpi
            Me.resolutionToolStripDropDownButton.DropDownItems.Clear()
            Dim _resolutions = Me._twain32.Capabilities.XResolution.Get()
            If _resolutions.Count < 20 Then
                For i = 0 To _resolutions.Count - 1 Step 1
                    Me.resolutionToolStripDropDownButton.DropDownItems.Add(String.Format("{0:N0} dpi", _resolutions(i)), Nothing, AddressOf Me._ResolutionItemSelected).Tag = _resolutions(i)
                Next
                Me._ResolutionItemSelected(Me.resolutionToolStripDropDownButton.DropDownItems(_resolutions.DefaultIndex), New EventArgs())
            End If

            'Get pixel types
            Me.pixelTypesToolStripDropDownButton.DropDownItems.Clear()
            Dim _pixelTypes = Me._twain32.Capabilities.PixelType.Get()
            For i = 0 To _pixelTypes.Count - 1 Step 1
                Me.pixelTypesToolStripDropDownButton.DropDownItems.Add(String.Format("{0}", _pixelTypes(i)), Nothing, AddressOf Me._PixelTypeItemSelected).Tag = _pixelTypes(i)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub NewToolStripButton_Click(sender As System.Object, e As System.EventArgs) Handles NewToolStripButton.Click
        Try

            '#region Examples of the capabilities

            'Brightness
            If (Me._twain32.IsCapSupported(TwCap.Brightness) And TwQC.Set) <> 0 Then
                Me._twain32.SetCap(TwCap.Brightness, 0.0F) 'Allowed Values: -1000.0F to +1000.0F; Default Value: 0.0F;
            End If

            'Contrast
            If (Me._twain32.IsCapSupported(TwCap.Contrast) And TwQC.Set) <> 0 Then
                Me._twain32.SetCap(TwCap.Contrast, 0.0F) 'Allowed Values: -1000.0F to +1000.0F; Default Value: 0.0F;
            End If

            '#endregion

            Me._twain32.Acquire()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SaveToolStripButton_Click(sender As System.Object, e As System.EventArgs) Handles SaveToolStripButton.Click
        Try
            If Not Me.PictureBox1.Image Is Nothing Then
                If Me.SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    Me.PictureBox1.Image.Save(Me.SaveFileDialog1.FileName, ImageFormat.Jpeg)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PrintToolStripButton_Click(sender As System.Object, e As System.EventArgs) Handles PrintToolStripButton.Click
        Try
            If Not Me.PictureBox1.Image Is Nothing Then
                If Me.PrintDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    Me.PrintDialog1.Document.Print()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub CopyToolStripButton_Click(sender As System.Object, e As System.EventArgs) Handles CopyToolStripButton.Click
        Try
            Clipboard.SetImage(Me.PictureBox1.Image)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PasteToolStripButton_Click(sender As System.Object, e As System.EventArgs) Handles PasteToolStripButton.Click
        Try
            If Clipboard.ContainsImage() Then
                Me.PictureBox1.Image = Clipboard.GetImage()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub _ResolutionItemSelected(sender As Object, e As EventArgs)
        Try
            Dim _item As ToolStripItem = sender
            Me.resolutionToolStripDropDownButton.Text = _item.Text
            Me.resolutionToolStripDropDownButton.Tag = _item.Tag
            Me._twain32.Capabilities.XResolution.Set(_item.Tag)
            Me._twain32.Capabilities.YResolution.Set(_item.Tag)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub _PixelTypeItemSelected(sender As Object, e As EventArgs)
        Try
            Dim _item As ToolStripItem = sender
            Me.pixelTypesToolStripDropDownButton.Text = _item.Text
            Me.pixelTypesToolStripDropDownButton.Tag = _item.Tag
            Me._twain32.Capabilities.PixelType.Set(_item.Tag)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As System.Object, e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Try
            e.Graphics.DrawImageUnscaled(
                Me.PictureBox1.Image,
                e.PageSettings.Margins.Left, e.PageSettings.Margins.Top)
            e.HasMorePages = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

End Class