﻿/* Этот файл является частью примеров использования библиотеки Saraff.TwainX.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.TwainX.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.TwainX.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.TwainX.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.TwainX.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.TwainX.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.TwainX.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using Saraff.Tiff;
using Saraff.Tiff.Core;
using Saraff.TwainX.Extensions;

namespace Saraff.TwainX.WinFormsSample2 {

    public partial class Form1:Form {
        private bool _isExtImageInfoAllowed;
        private XDsm _dsm = null;

        public Form1() {
            this.InitializeComponent();

            #region Initialize IoC container

            var _services = new IoC.ServiceContainer();
            _services.Load(this.GetType().Assembly);
            foreach(IComponent _item in this.components.Components) {
                _services.Add(_item);
            }
            this.components=_services;

            #endregion

            try {

                #region Заполняем список источников данных

                this.dataSourcesToolStripComboBox.Items.Clear();
                this.dataSourcesToolStripComboBox.Items.AddRange(this.Dsm.DataSources.Select(x => x.Identity.Name).ToArray());
                if(this.Dsm.DataSources.Count()>0) {
                    this.dataSourcesToolStripComboBox.SelectedIndex=this.Dsm.TwainX.SourceIndex;
                }

                #endregion

            } catch(TwainException ex) {
                MessageBox.Show(ex.Message,"SAMPLE2",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void _ToLog(Exception ex) {
            MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            Debug.WriteLine(string.Format("{0}: {1}\n{2}",ex.GetType().Name,ex.Message,ex.StackTrace));
        }

        private void _ShowImageInfo(TwainX.XferDoneEventArgs e) {
            try {
                this.textBox1.ResetText();

                #region Image info

                this.textBox1.AppendText(string.Format("Image Info:{0}",Environment.NewLine));
                var _imageInfo=e.GetImageInfo();
                this.textBox1.AppendText(string.Format("YResolution={0}; XResolution={1}; Compression={7} PixelType={2}; SamplesPerPixel={3}; ImageWidth={4}; ImageLength={5};{6}",_imageInfo.YResolution,_imageInfo.XResolution,_imageInfo.PixelType,_imageInfo.BitsPerSample.Length,_imageInfo.ImageWidth,_imageInfo.ImageLength,Environment.NewLine,_imageInfo.Compression));
                System.Diagnostics.Debug.WriteLine(string.Format("Получено изображение размером {0}x{1}",_imageInfo.ImageWidth,_imageInfo.ImageLength));

                #endregion

                #region Extended Image Info

                if(this._isExtImageInfoAllowed) { // if extended image info support
                    this.textBox1.AppendText("Extended Image Info:");
                    var _extImageInfo=e.GetExtImageInfo(new TwEI[] { TwEI.BarCodeCount,TwEI.BarCodeType,TwEI.BarCodeTextLength,TwEI.Camera,TwEI.Frame,TwEI.PixelFlavor,TwEI.DocumentNumber });

                    #region Show info

                    foreach(var _item in _extImageInfo) {
                        this.textBox1.AppendText(string.Format("{0}{1} = ",Environment.NewLine,_item.InfoId));
                        if(_item.IsSuccess) {
                            if(_item.Value is object[]) {
                                foreach(var _value in _item.Value as object[]) {
                                    this.textBox1.AppendText(string.Format("{0}; ",_value));
                                }
                            } else {
                                this.textBox1.AppendText(string.Format("{0}; ",_item.Value));
                            }
                        }
                        if(_item.IsNotAvailable) {
                            this.textBox1.AppendText("NotAvailable");
                        }
                        if(_item.IsNotSupported) {
                            this.textBox1.AppendText("NotSupported");
                        }
                    }

                }

                #endregion

                #endregion

            } catch(Exception ex) {
                this._ToLog(ex);
                Debug.WriteLine(string.Format("{0}: {1}\n{2}",ex.GetType().Name,ex.Message,ex.StackTrace));
            }
        }

        private void _AcquireError(TwainX.AcquireErrorEventArgs e) {
            try {
                this.textBox1.AppendText(string.Format("{4}{0}: {1} ConditionCode = {2}; ReturnCode = {3};{4}",e.Exception.GetType().Name,e.Exception.Message,e.Exception.ConditionCode,e.Exception.ReturnCode,Environment.NewLine));
                Debug.WriteLine(string.Format(string.Format("{4}{0}: {1}{4}{5}{4} ConditionCode = {2}; ReturnCode = {3};",e.Exception.GetType().Name,e.Exception.Message,e.Exception.ConditionCode,e.Exception.ReturnCode,Environment.NewLine,e.Exception.StackTrace)));
                for(Exception _ex = e.Exception.InnerException; _ex!=null; _ex=_ex.InnerException) {
                    this.textBox1.AppendText(string.Format("{2}{0}: {1} {2}",_ex.GetType().Name,_ex.Message,Environment.NewLine));
                    Debug.WriteLine(string.Format(string.Format("{2}{0}: {1}{2}{3}",_ex.GetType().Name,_ex.Message,Environment.NewLine,_ex.StackTrace)));
                }
            } catch(Exception ex) {
                this._ToLog(ex);
                Debug.WriteLine(string.Format("{0}: {1}\n{2}",ex.GetType().Name,ex.Message,ex.StackTrace));
            }
        }

        private void _ToolStripItemSelectedHandler(object sender,EventArgs e) {
            try {
                if(sender is ToolStripItem _item) {
                    this._UpdateToolStripItemParent(_item);
                }
            } catch(Exception ex) {
                this._ToLog(ex);
            }
        }

        private void _UpdateToolStripItemParent(ToolStripItem item) {
            var _parent = item.OwnerItem;
            _parent.Text=item.Text;
            _parent.Tag=item.Tag;
        }

        private Bitmap CurrentBitmap {
            get {
                return this.pictureBox1.Image as Bitmap;
            }
            set {
                if(this.pictureBox1.Image!=null) {
                    this.pictureBox1.Image.Dispose();
                }
                this.pictureBox1.Image=value;
            }
        }

        private XDsm Dsm {
            get {
                if(this._dsm==null) {
                    this._dsm=XDsm.Create(this._twainx);
                }
                return this._dsm;
            }
        }

        #region Toolbar events handlers

        private void dataSourcesToolStripComboBox_SelectedIndexChanged(object sender,EventArgs e) {
            try {
                var _ds = this.Dsm.DataSources.ElementAtOrDefault(this.dataSourcesToolStripComboBox.SelectedIndex);

                #region Заполняем список доступных разрешений dpi

                this.resolutionToolStripDropDownButton.DropDownItems.Clear();
                var _resolutions = _ds.GetCapability<float>(TwCap.XResolution).Values;
                this.resolutionToolStripDropDownButton.DropDownItems.AddRange(
                    _resolutions?
                        .Where(x => _resolutions.Count()<20 ? true : x.Value%100==0)
                        .Select(x => new ToolStripMenuItem(
                            string.Format("{0:N0} dpi",x.Value),
                            null,
                            this._ToolStripItemSelectedHandler) {Tag=x.Value, Name=x.IsCurrent ? "Y" : x.Value.ToString()} as ToolStripItem)
                        .ToArray());

                    this._UpdateToolStripItemParent(this.resolutionToolStripDropDownButton.DropDownItems["Y"]??this.resolutionToolStripDropDownButton.DropDownItems[0]);

                #endregion

                #region Заполняем список доступных типов пикселей

                this.pixelTypesToolStripDropDownButton.DropDownItems.Clear();
                this.pixelTypesToolStripDropDownButton.DropDownItems.AddRange(
                    _ds.GetCapability<TwPixelType>(TwCap.IPixelType).Values
                    .Select(x => new ToolStripMenuItem(
                        x.Value.ToString(),
                        null,
                        this._ToolStripItemSelectedHandler) {Tag=x.Value,Name=x.IsCurrent ? "Y" : x.Value.ToString()} as ToolStripItem)
                    .ToArray());
                this._UpdateToolStripItemParent(this.pixelTypesToolStripDropDownButton.DropDownItems["Y"]);

                #endregion

                #region Заполняем список доступных режимов передачи данных

                this.xferModeToolStripDropDownButton.DropDownItems.Clear();
                this.xferModeToolStripDropDownButton.DropDownItems.AddRange(
                    _ds.GetCapability<TwSX>(TwCap.IXferMech).Values
                    .Select(x => new ToolStripMenuItem(
                        x.Value.ToString(),
                        null,
                        (sender2,e2)=> {
                            this._ToolStripItemSelectedHandler(sender2,e2);
                            ToolStripItem _item = sender2 as ToolStripItem;
                            if(_item!=null) {
                                this.fileFormatToolStripDropDownButton.Enabled=(TwSX)_item.Tag==TwSX.File;
                            }
                        }) {Tag=x.Value,Name=x.IsCurrent ? "Y" : x.Value.ToString()} as ToolStripItem)
                    .ToArray());
                this._UpdateToolStripItemParent(this.xferModeToolStripDropDownButton.DropDownItems["Y"]);

                #endregion

                #region Заполняет список доступных форматов файла изображения

                this.fileFormatToolStripDropDownButton.DropDownItems.Clear();
                this.fileFormatToolStripDropDownButton.DropDownItems.AddRange(
                    _ds.GetCapability<TwFF>(TwCap.ImageFileFormat).Values
                    .Select(x => new ToolStripMenuItem(
                        x.Value.ToString(),
                        null,
                        this._ToolStripItemSelectedHandler) {Tag=x.Value,Name=x.IsCurrent ? "Y" : x.Value.ToString()} as ToolStripItem)
                    .ToArray());
                this._UpdateToolStripItemParent(this.fileFormatToolStripDropDownButton.DropDownItems["Y"]);

                #endregion

                #region Проверяем возможность получения информации о изображении

                var _isSupported =(_ds.GetCapability<bool>(TwCap.ExtImageInfo).IsSupported&TwQC.Get)!=0;
                this._isExtImageInfoAllowed=_isSupported&&(_ds.GetCapability<bool>(TwCap.ExtendedCaps).IsSupported&TwQC.Get)!=0&&_ds.GetCapability<bool>(TwCap.ExtendedCaps).Values.First(x => x.IsCurrent).Value;
                this.toolStripStatusLabel1.Text=string.Format("Extended image info: {0}supported{1}",_isSupported?"":"not ",_isSupported?this._isExtImageInfoAllowed?", allowed":", not allowed":"");

                #endregion

                this.pictureBox1.Select();
            } catch(TwainException ex) {
                Debug.WriteLine(string.Format("{0}: {1}\nReturnCode = {3}; ConditionCode = {4};\n{2}",ex.GetType().Name,ex.Message,ex.StackTrace,ex.ReturnCode,ex.ConditionCode));
            } catch(Exception ex) {
                this._ToLog(ex);
                Debug.WriteLine(string.Format("{0}: {1}\n{2}",ex.GetType().Name,ex.Message,ex.StackTrace));
            }
        }

        private void newToolStripButton_Click(object sender,EventArgs e) {
            try {
                var _ds = this.Dsm
                    .DataSources.ElementAtOrDefault(this.dataSourcesToolStripComboBox.SelectedIndex)
                    .GetCapability<float>(TwCap.XResolution).Set(x => (float)this.resolutionToolStripDropDownButton.Tag).DataSource
                    .GetCapability<float>(TwCap.YResolution).Set(x => (float)this.resolutionToolStripDropDownButton.Tag).DataSource
                    .GetCapability<TwPixelType>(TwCap.IPixelType).Set(x => (TwPixelType)pixelTypesToolStripDropDownButton.Tag).DataSource;

                switch((TwSX)xferModeToolStripDropDownButton.Tag) {
                    case TwSX.Native:
                        _ds.NativeTransfer(
                            x => this.CurrentBitmap=x.CreateImage(this.ImageFactory),
                            this._ShowImageInfo,
                            null,
                            this._AcquireError);
                        break;
                    case TwSX.Memory:
                        _ds.MemoryTransfer(
                            x => {
                                if(TiffMemXfer.Current==null) {
                                    TiffMemXfer.Create((int)x.BufferSize);
                                }

                                #region Color Map

                                if(x.ImageInfo.PixelType==TwPixelType.Palette) {
                                    TwainX.ColorPalette _palette = _ds.TwainX.Palette.Get();
                                    TiffMemXfer.Current.ColorMap=new ushort[_palette.Colors.Length*3];
                                    for(int i = 0; i<_palette.Colors.Length; i++) {
                                        TiffMemXfer.Current.ColorMap[i]=(ushort)(_palette.Colors[i].R);
                                        TiffMemXfer.Current.ColorMap[i+_palette.Colors.Length]=(ushort)(_palette.Colors[i].G);
                                        TiffMemXfer.Current.ColorMap[i+(_palette.Colors.Length<<1)]=(ushort)(_palette.Colors[i].B);
                                    }
                                }

                                #endregion

                            },
                            x => {
                                long _bitsPerRow = x.ImageInfo.BitsPerPixel*x.ImageMemXfer.Columns;
                                long _bytesPerRow = Math.Min(x.ImageMemXfer.BytesPerRow,(_bitsPerRow>>3)+((_bitsPerRow&0x07)!=0 ? 1 : 0));
                                using(MemoryStream _stream = new MemoryStream()) {
                                    for(int i = 0; i<x.ImageMemXfer.Rows; i++) {
                                        _stream.Position=0;
                                        _stream.Write(x.ImageMemXfer.ImageData,(int)(x.ImageMemXfer.BytesPerRow*i),(int)_bytesPerRow);
                                        TiffMemXfer.Current.Strips.Add(TiffMemXfer.Current.Writer.WriteData(_stream.ToArray()));
                                        TiffMemXfer.Current.StripByteCounts.Add((uint)_stream.Length);
                                    }
                                }
                            },
                            x => {
                                this._ShowImageInfo(x);

                                TwainX.ImageInfo _info = x.GetImageInfo();
                                Collection<ITag> _tags = new Collection<ITag> {
                                    Tag<uint>.Create(TiffTags.ImageWidth,(uint)_info.ImageWidth),
                                    Tag<uint>.Create(TiffTags.ImageLength,(uint)_info.ImageLength),
                                    Tag<ushort>.Create(TiffTags.SamplesPerPixel,(ushort)_info.BitsPerSample.Length),
                                    Tag<ushort>.Create(TiffTags.BitsPerSample,_info.BitsPerSample.Select(y => (ushort)y).ToArray()),
                                    Tag<ushort>.Create(TiffTags.Orientation,(ushort)TiffOrientation.TOPLEFT),
                                    Tag<TiffCompression>.Create(TiffTags.Compression,TiffCompression.NONE),
                                    Tag<TiffResolutionUnit>.Create(TiffTags.ResolutionUnit,_ds.GetCapability<TwUnits>(TwCap.IUnits).Values.Where(y => y.IsCurrent).Select(y => {
                                        switch(y.Value) {
                                            case TwUnits.Centimeters:
                                                return TiffResolutionUnit.CENTIMETER;
                                            case TwUnits.Inches:
                                                return TiffResolutionUnit.INCH;
                                            default:
                                                return TiffResolutionUnit.NONE;
                                        }
                                    }).First()),
                                    Tag<ulong>.Create(TiffTags.XResolution,(1UL<<32)|(ulong)_info.XResolution),
                                    Tag<ulong>.Create(TiffTags.YResolution,(1UL<<32)|(ulong)_info.YResolution),
                                    Tag<TiffHandle>.Create(TiffTags.StripOffsets,TiffMemXfer.Current.Strips.ToArray()),
                                    Tag<uint>.Create(TiffTags.StripByteCounts,TiffMemXfer.Current.StripByteCounts.ToArray()),
                                    Tag<uint>.Create(TiffTags.RowsPerStrip,1u),
                                    Tag<char>.Create(TiffTags.Software,Application.ProductName.ToCharArray()),
                                    Tag<char>.Create(TiffTags.Model,_ds.Identity.Name.ToCharArray()),
                                    Tag<char>.Create(TiffTags.DateTime,DateTime.Now.ToString("yyyy:MM:dd HH:mm:ss").PadRight(20,'\0').ToCharArray()),
                                    Tag<char>.Create(TiffTags.HostComputer,Environment.MachineName.ToCharArray()),
                                    Tag<ushort>.Create(TiffTags.PlanarConfiguration,(ushort)TiffPlanarConfig.CONTIG),
                                    Tag<char>.Create(TiffTags.Copyright,((AssemblyCopyrightAttribute)this.GetType().Assembly.GetCustomAttributes(typeof(AssemblyCopyrightAttribute),false)[0]).Copyright.ToCharArray())
                                };
                                switch(_info.PixelType) {
                                    case TwPixelType.BW:
                                        _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation,TiffPhotoMetric.BlackIsZero));
                                        break;
                                    case TwPixelType.Gray:
                                        _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation,TiffPhotoMetric.BlackIsZero));
                                        break;
                                    case TwPixelType.Palette:
                                        _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation,TiffPhotoMetric.Palette));
                                        _tags.Add(Tag<ushort>.Create(TiffTags.ColorMap,TiffMemXfer.Current.ColorMap));
                                        break;
                                    case TwPixelType.RGB:
                                        _tags.Add(Tag<TiffPhotoMetric>.Create(TiffTags.PhotometricInterpretation,TiffPhotoMetric.RGB));
                                        break;
                                    default:
                                        break;
                                }
                                TiffMemXfer.Current.Handle=TiffMemXfer.Current.Writer.WriteImageFileDirectory(TiffMemXfer.Current.Handle,_tags);
                                TiffMemXfer.Current.Strips.Clear();
                                TiffMemXfer.Current.StripByteCounts.Clear();
                            },
                            () => {
                                try {
                                    TiffMemXfer.Current.Writer.BaseStream.Seek(0,SeekOrigin.Begin);
                                    this.CurrentBitmap=Image.FromStream(TiffMemXfer.Current.Writer.BaseStream) as Bitmap;
                                } finally {
                                    TiffMemXfer.Dispose();
                                }
                            },
                            this._AcquireError);
                        break;
                    case TwSX.MemFile:
                        _ds.MemFileTransfer(
                            x => MemFileXfer.Create((int)x.BufferSize,fileFormatToolStripDropDownButton.Tag.ToString().ToLower()),
                            x => MemFileXfer.Current.Writer.Write(x.ImageMemXfer.ImageData),
                            this._ShowImageInfo,
                            ()=> {
                                try {
                                    MemFileXfer.Current.Writer.BaseStream.Seek(0,SeekOrigin.Begin);
                                    this.CurrentBitmap=Image.FromStream(MemFileXfer.Current.Writer.BaseStream) as Bitmap;
                                } finally {
                                    MemFileXfer.Dispose();
                                }
                            },
                            this._AcquireError);
                        break;
                    case TwSX.File:
                        _ds.GetCapability<TwFF>(TwCap.ImageFileFormat).Set(x => (TwFF)fileFormatToolStripDropDownButton.Tag).DataSource
                            .FileTransfer(
                                x => x.FileName=string.Format(@"FileXferTransfer_{0}.{1}",DateTime.Now.ToString("yyyyMMddHHmmss"),fileFormatToolStripDropDownButton.Tag.ToString().ToLower()),
                                x => this.CurrentBitmap=Image.FromFile(x.ImageFileXfer.FileName) as Bitmap,
                                this._ShowImageInfo,
                                null,
                                this._AcquireError);
                        break;
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void saveToolStripButton_Click(object sender,EventArgs e) {
            try {
                if(this.saveFileDialog1.ShowDialog()==DialogResult.OK) {
                    this.pictureBox1.Image.Save(this.saveFileDialog1.FileName,ImageFormat.Bmp);
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void printToolStripButton_Click(object sender,EventArgs e) {
            try {
                if(this.printDialog1.ShowDialog()==DialogResult.OK) {
                    this.printDialog1.Document.Print();
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void copyToolStripButton_Click(object sender,EventArgs e) {
            try {
                Clipboard.SetImage(this.CurrentBitmap);
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void pasteToolStripButton_Click(object sender,EventArgs e) {
            try {
                if(Clipboard.ContainsImage()) {
                    this.CurrentBitmap=Clipboard.GetImage() as Bitmap;
                }
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void printDocument1_PrintPage(object sender,PrintPageEventArgs e) {
            try {
                e.Graphics.DrawImageUnscaled(
                    this.CurrentBitmap,
                    e.PageSettings.Margins.Left,e.PageSettings.Margins.Top);
                e.HasMorePages=false;
            } catch(Exception ex) {
                MessageBox.Show(ex.Message,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        private sealed class TiffMemXfer {

            public static void Create(int bufferSize) {
                TiffMemXfer.Current=new TiffMemXfer {
                    Writer=TiffWriter.Create(File.Create(string.Format("MemXferTransfer_{0}.tif",DateTime.Now.ToString("yyyyMMddHHmmss")),bufferSize)),
                    Strips=new List<TiffHandle>(),
                    StripByteCounts=new List<uint>()
                };
                TiffMemXfer.Current.Handle=TiffMemXfer.Current.Writer.WriteHeader();
            }

            public static void Dispose() {
                if(TiffMemXfer.Current!=null) {
                    TiffMemXfer.Current=null;
                }
            }

            public static TiffMemXfer Current {
                get;
                private set;
            }

            public TiffHandle Handle {
                get;
                set;
            }

            public TiffWriter Writer {
                get;
                private set;
            }

            public List<TiffHandle> Strips {
                get;
                private set;
            }

            public List<uint> StripByteCounts {
                get;
                private set;
            }

            public ushort[] ColorMap {
                get;
                set;
            }
        }

        private sealed class MemFileXfer {

            public static void Create(int bufferSize,string ext) {
                if(MemFileXfer.Current!=null&&MemFileXfer.Current.Writer!=null) {
                    MemFileXfer.Current.Writer.BaseStream.Dispose();
                }
                MemFileXfer.Current=new MemFileXfer {
                    Writer=new BinaryWriter(File.Create(string.Format("MemFileXferTransfer_{0}.{1}",DateTime.Now.ToString("yyyyMMddHHmmss"),ext),bufferSize))
                };
            }

            public static void Dispose() {
                if(MemFileXfer.Current==null) {
                    MemFileXfer.Current=null;
                }
            }

            public static MemFileXfer Current {
                get;
                private set;
            }

            public BinaryWriter Writer {
                get;
                private set;
            }
        }

        private delegate TResult Func<T,TResult>(T arg);

        private IServiceProvider ServiceProvider {
            get {
                return this.components as IServiceProvider;
            }
        }

        public IImageFactory<Bitmap> ImageFactory {
            get {
                return this.ServiceProvider.GetService(typeof(IImageFactory<Bitmap>)) as IImageFactory<Bitmap>;
            }
        }

    }

    internal sealed class Debug {

        public static void WriteLine(string text) {
            switch(Environment.OSVersion.Platform) {
                case PlatformID.Unix:
                    Console.Error.WriteLine(text);
                    break;
                case PlatformID.MacOSX:
                    throw new NotImplementedException();
                default:
                    System.Diagnostics.Debug.WriteLine(text);
                    break;
            }
        }
    }
}
