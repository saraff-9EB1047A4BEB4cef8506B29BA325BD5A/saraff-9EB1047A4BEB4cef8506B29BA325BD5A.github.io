﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Provider;
using Windows.Storage.Streams;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using TW = Saraff.Twain.UwpSample1.TwainServiceReference;

// Документацию по шаблону элемента "Пустая страница" см. по адресу http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Saraff.Twain.UwpSample1 {

    /// <summary>
    /// Пустая страница, которую можно использовать саму по себе или для перехода внутри фрейма.
    /// </summary>
    public sealed partial class MainPage:Page {
        private TW.TwainServiceClient _service;
        private byte[] _imageData;

        public MainPage() {
            this.InitializeComponent();
        }

        private async Task _LoadAsync() {
            this._status.Content="Getting a datasources...";
            try {
                var _sources = await (await this._GetTwainServiceAsync()).GetSourcesAsync();
                this._twainSources.Source=_sources;
                this._twainSources.View.MoveCurrentToPosition(_sources.FindIndex(x => x.IsDefault));
                this._twainSources.View.CurrentChanged+=this._TwainSourceCurrentChanged;
                await this._LoadCapsAsync();
            } finally {
                this._status.Content=string.Empty;
                this.datasourceComboBox.IsEnabled=true;
            }
        }

        private async Task _LoadCapsAsync() {
            this._status.Content="Getting a capabilities...";
            try {
                var _caps = await (await this._GetTwainServiceAsync()).GetCapsAsync(
                    this._twainSources.View.CurrentItem as TW.Source,
                    new List<TW.TwCap> {
                        TW.TwCap.XResolution,
                        TW.TwCap.IPixelType
                    });

                #region XResolution

                for(var _cap = _caps.FirstOrDefault(x => x.Cap==TW.TwCap.XResolution); _cap!=null;) {
                    this._resolutions.Source=_cap.Values;
                    this._resolutions.View.MoveCurrentTo(_cap.Current);
                    break;
                }

                #endregion

                #region IPixelType

                for(var _cap = _caps.FirstOrDefault(x => x.Cap==TW.TwCap.IPixelType); _cap!=null;) {
                    this._pixelTypes.Source=_cap.Values;
                    this._pixelTypes.View.MoveCurrentTo(_cap.Current);
                    break;
                }

                #endregion

            } finally {
                this._status.Content=string.Empty;
                this.resolutionComboBox.IsEnabled=this.pixelTypeComboBox.IsEnabled=this.acquireButton.IsEnabled=true;
            }
        }

        private async Task _AcquireAsync() {
            this._status.Content="Acquiring...";
            try {
                this._imageData= await (await this._GetTwainServiceAsync()).AcquireAsync(
                    this._twainSources.View.CurrentItem as TW.Source,
                    new List<TW.CapEnum> {
                        new TW.CapEnum{Cap=TW.TwCap.XResolution,Current=this._resolutions.View.CurrentItem as TW.CapValue},
                        new TW.CapEnum{Cap=TW.TwCap.YResolution,Current=this._resolutions.View.CurrentItem as TW.CapValue},
                        new TW.CapEnum{Cap=TW.TwCap.IPixelType,Current=this._pixelTypes.View.CurrentItem as TW.CapValue}
                    });
                this.saveButton.IsEnabled=true;
                using(var _stream = new MemoryStream(this._imageData)) {
                    var _img = new BitmapImage {
                        CreateOptions=BitmapCreateOptions.None
                    };
                    _stream.Seek(0,SeekOrigin.Begin);
                    await _img.SetSourceAsync(_stream.AsRandomAccessStream());
                    this._imageControl.Source=_img;
                }
            } finally {
                this._status.Content=string.Empty;
            }
        }

        private async Task _SaveAsync() {
            var _savePicker = new FileSavePicker {
                SuggestedStartLocation=PickerLocationId.DocumentsLibrary,
                SuggestedFileName="New Image",
                FileTypeChoices={ { "Image",new List<string> { ".jpg" } } }
            };
            var _file = await _savePicker.PickSaveFileAsync();
            if(_file!=null) {
                CachedFileManager.DeferUpdates(_file);
                using(var _stream = await _file.OpenStreamForWriteAsync()) {
                    await _stream.WriteAsync(this._imageData,0,this._imageData.Length);
                }
                var _status = await CachedFileManager.CompleteUpdatesAsync(_file);
                if(_status!=FileUpdateStatus.Complete) {
                    await new MessageDialog(string.Format("File \"{0}\" couldn't be saved.",_file.Name),_status.ToString()).ShowAsync();
                }
            }
        }

        private async Task<TW.ITwainService> _GetTwainServiceAsync() {
            if(this._service==null) {
                this._service=new TW.TwainServiceClient(TW.TwainServiceClient.EndpointConfiguration.twain,TW.TwainServiceClient.GetEndpointAddressFromHost(TW.TwainServiceClient.EndpointConfiguration.twain,this.addressTextBox.Text));
                await this._service.OpenAsync();
            }
            return this._service;
        }

        private async Task _CloseConnectionAsync() {
            if(this._service!=null) {
                await this._service.CloseAsync();
                this._service=null;
            }
        }

        #region Handlers

        private async void connectButton_Click(object sender,RoutedEventArgs e) {
            try {
                this.datasourceComboBox.IsEnabled=this.resolutionComboBox.IsEnabled=this.pixelTypeComboBox.IsEnabled=this.acquireButton.IsEnabled=false;
                await this._LoadAsync();
            } catch(Exception ex) {
                await new MessageDialog(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name).ShowAsync();
            }
        }

        private async void addressTextBox_TextChanged(object sender,TextChangedEventArgs e) {
            try {
                await this._CloseConnectionAsync();
                this.connectButton.IsEnabled=!string.IsNullOrEmpty(this.addressTextBox.Text);
            }catch(Exception ex) {
                await new MessageDialog(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name).ShowAsync();
            }
        }

        private async void _TwainSourceCurrentChanged(object sender,object e) {
            try {
                this.resolutionComboBox.IsEnabled=this.pixelTypeComboBox.IsEnabled=this.acquireButton.IsEnabled=false;
                await this._LoadCapsAsync();
            } catch(Exception ex) {
                await new MessageDialog(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name).ShowAsync();
            }
        }

        private async void acquireButton_Click(object sender,RoutedEventArgs e) {
            try {
                await this._AcquireAsync();
            } catch(Exception ex) {
                await new MessageDialog(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name).ShowAsync();
            }
        }

        private async void _slider_ValueChanged(object sender,RangeBaseValueChangedEventArgs e) {
            try {
                this._scrollViewer.ChangeView(0f,0f,(float)this._slider.Value/100f);
            } catch(Exception ex) {
                await new MessageDialog(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name).ShowAsync();
            }
        }

        private async void saveButton_Click(object sender,RoutedEventArgs e) {
            try {
                await this._SaveAsync();
            } catch(Exception ex) {
                await new MessageDialog(string.Format("{1}{0}{2}",Environment.NewLine,ex.Message,ex.StackTrace),ex.GetType().Name).ShowAsync();
            }
        }

        #endregion
    }
}
