﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.ServiceModel;
using System.Text;
using System.IO;
using System.Drawing.Imaging;
using Saraff.Twain.Aux;
using Newtonsoft.Json;

namespace Saraff.Twain.Service {

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerCall)]
    public class TwainService:ITwainService, ITwainWebService, IPolicyRetriever {
        private const string _x86Aux="Saraff.Twain.Aux_x86.exe";
        private const string _msilAux="Saraff.Twain.Aux_MSIL.exe";

        #region ITwainService

        public IEnumerable<Source> GetSources() {
            try {
                Collection<Source> _result=new Collection<Source>();
                TwainExternalProcess.Execute(
                    Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),TwainService._x86Aux),
                    twain => {
                        try {
                            for(var i=0; i<twain.SourcesCount; i++) {
                                _result.Add(new Source {
                                    Platform=SourcePlatform.X86_32,
                                    Version=twain.IsTwain2Supported?DsmVersion.V2:DsmVersion.V1,
                                    Id=i,
                                    Name=twain.GetSourceProductName(i),
                                    IsDefault=twain.SourceIndex==i
                                });
                            }
                        } catch {
                        }
                    });
                TwainExternalProcess.Execute(
                    Path.Combine(Path.GetDirectoryName(this.GetType().Assembly.Location),TwainService._msilAux),
                    twain => {
                        try {
                            if(!twain.IsTwain2Supported) {
                                return;
                            }
                            for(var i=0; i<twain.SourcesCount; i++) {
                                _result.Add(new Source {
                                    Platform=Environment.Is64BitOperatingSystem?SourcePlatform.X86_64:SourcePlatform.X86_32,
                                    Version=twain.IsTwain2Supported?DsmVersion.V2:DsmVersion.V1,
                                    Id=i,
                                    Name=twain.GetSourceProductName(i),
                                    IsDefault=twain.SourceIndex==i
                                });
                            }
                        } catch {
                        }
                    });
                return _result;
            } catch(Exception ex) {
                var _message=string.Empty;
                for(var _ex=ex; _ex!=null; _ex=_ex.InnerException) {
                    _message+=string.Format("{0}: {1}{3}{2}{3}{3}",_ex.GetType().Name,_ex.Message,_ex.StackTrace,Environment.NewLine);
                }
                throw new FaultException(_message);
            }
        }

        public IEnumerable<CapEnum> GetCaps(Source source,IEnumerable<TwCap> caps) {
            try {
                var _formatter=new BinaryFormatter();
                var _result=new Collection<CapEnum>();
                TwainExternalProcess.Execute(
                    TwainService._GetExecFileName(source),
                    twain => {
                        try {
                            twain.SourceIndex=source.Id;
                            twain.OpenDataSource();

                            foreach(var _cap in caps) {
                                if((twain.IsCapSupported(_cap)&TwQC.Get)!=0) {
                                    _result.Add(new CapEnum {
                                        Cap=_cap,
                                        Values=new Func<IEnumerable<CapValue>>(() => {
                                            var _enum=TwainService.EnumerationFromObject(twain.GetCap(_cap));
                                            var _res=new Collection<CapValue>();

                                            for(var i=0; i<_enum.Count; i++) {
                                                using(var _stream=new MemoryStream()) {
                                                    _formatter.Serialize(_stream,_enum[i]);
                                                    _res.Add(new CapValue {
                                                        Name=_enum[i].ToString(),
                                                        RawValue=_stream.ToArray()
                                                    });
                                                }
                                            }

                                            return _res;
                                        })(),
                                        Current=new Func<CapValue>(() => {
                                            var _value=twain.GetCurrentCap(_cap);
                                            using(var _stream=new MemoryStream()) {
                                                _formatter.Serialize(_stream,_value);
                                                return new CapValue {
                                                    Name=_value.ToString(),
                                                    RawValue=_stream.ToArray()
                                                };
                                            }
                                        })()
                                    });
                                }
                            }
                        } catch {
                        }
                    });
                return _result;
            } catch(Exception ex) {
                var _message=string.Empty;
                for(var _ex=ex; _ex!=null; _ex=_ex.InnerException) {
                    _message+=string.Format("{0}: {1}{3}{2}{3}{3}",_ex.GetType().Name,_ex.Message,_ex.StackTrace,Environment.NewLine);
                }
                throw new FaultException(_message);
            }
        }

        public Stream Acquire(Source source,IEnumerable<CapEnum> caps) {
            try {
                var _formatter=new BinaryFormatter();
                var _result=new MemoryStream();
                TwainExternalProcess.Execute(
                    TwainService._GetExecFileName(source),
                    twain => {
                        twain.EndXfer+=(sender,e) => {
                            try {
                                using(var _image = e.Image) {
                                    _image.Save(_result,ImageFormat.Jpeg);
                                    _result.Seek(0,SeekOrigin.Begin);
                                }
                            } catch {
                            }
                        };
                        twain.SourceIndex=source.Id;
                        twain.OpenDataSource();

                        foreach(var _cap in caps) {
                            using(var _stream=new MemoryStream(_cap.Current.RawValue)) {
                                twain.SetCap(_cap.Cap,_formatter.Deserialize(_stream));
                            }
                        }

                        twain.Capabilities.XferCount.Set(1);
                        twain.Capabilities.Indicators.Set(false);

                        twain.Acquire();
                    });
                return _result;
                ;
            } catch(Exception ex) {
                var _message=string.Empty;
                for(var _ex=ex; _ex!=null; _ex=_ex.InnerException) {
                    _message+=string.Format("{0}: {1}{3}{2}{3}{3}",_ex.GetType().Name,_ex.Message,_ex.StackTrace,Environment.NewLine);
                }
                throw new FaultException(_message);
            }
        }

        #endregion

        #region ITwainWebService

        public IEnumerable<CapEnum> GetCaps(string platform,string version,int sourceId,string caps) {
            return this.GetCaps(
                new Source {
                    Id=sourceId,
                    Version=TwainService._ToEnumValue<DsmVersion>(version),
                    Platform=TwainService._ToEnumValue<SourcePlatform>(platform)
                },
                caps.Split(new[] { "," },StringSplitOptions.RemoveEmptyEntries).Select(x => TwainService._ToEnumValue<TwCap>(x)));
        }

        public string Acquire(string platform,string version,int sourceId,string caps) {
            using(var _stream = this.Acquire(
                new Source {
                    Id=sourceId,
                    Version=TwainService._ToEnumValue<DsmVersion>(version),
                    Platform=TwainService._ToEnumValue<SourcePlatform>(platform)
                },
                JsonConvert.DeserializeObject<Dictionary<string,string>>(caps).Select(x => new CapEnum {
                    Cap=TwainService._ToEnumValue<TwCap>(x.Key),
                    Current=new CapValue { RawValue=JsonConvert.DeserializeObject<byte[]>(x.Value) }
                })) as MemoryStream) {

                return Convert.ToBase64String(_stream.ToArray());

            }
        }

        #endregion

        private static string _GetExecFileName(Source source) {
            return Path.Combine(Path.GetDirectoryName(typeof(TwainService).Assembly.Location),source.Platform==SourcePlatform.X86_64||source.Version==DsmVersion.V2?TwainService._msilAux:TwainService._x86Aux);
        }

        private static T _ToEnumValue<T>(string value) where T:struct {
            for(T _item; Enum.TryParse<T>(value,true,out _item);) {
                return _item;
            }
            throw new InvalidOperationException(string.Format("Can not convert \"{0}\" to \"{1}\".",value,typeof(T).FullName));
        }

        #region IPolicyRetriever

        public Stream GetSilverlightPolicy() {
            System.ServiceModel.Web.WebOperationContext.Current.OutgoingResponse.ContentType = "application/xml";
            return new MemoryStream(Encoding.UTF8.GetBytes(@"<?xml version=""1.0"" encoding=""utf-8"" ?>
                <access-policy>
                  <cross-domain-access>
                    <policy>
                      <allow-from http-request-headers=""*"">
                        <domain uri=""*"" />
                      </allow-from>
                      <grant-to>
                        <resource path=""/"" include-subpaths=""true"" />
                      </grant-to>
                    </policy>
                  </cross-domain-access>
                </access-policy>"));
        }

        #endregion

        private static Twain32.Enumeration EnumerationFromObject(object value) {
            if(value is Twain32.Range) {
                return Twain32.Enumeration.FromRange((Twain32.Range)value);
            }
            if(value is object[]) {
                return Twain32.Enumeration.FromArray((object[])value);
            }
            if(value is ValueType) {
                return Twain32.Enumeration.FromOneValue((ValueType)value);
            }
            if(value is string) {
                return Twain32.Enumeration.CreateEnumeration(new object[] { value },0,0);
            }
            return value as Twain32.Enumeration;
        }
    }
}
