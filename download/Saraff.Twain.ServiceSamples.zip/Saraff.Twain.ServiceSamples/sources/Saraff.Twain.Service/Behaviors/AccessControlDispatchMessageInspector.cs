﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Text;

namespace Saraff.Twain.Service.Behaviors {

    public sealed class AccessControlDispatchMessageInspector:IDispatchMessageInspector {

        public object AfterReceiveRequest(ref Message request,IClientChannel channel,InstanceContext instanceContext) {
            return (request.Properties[HttpRequestMessageProperty.Name] as HttpRequestMessageProperty)?.Headers["Origin"];
        }

        public void BeforeSendReply(ref Message reply,object correlationState) {
            string _origin = correlationState as string;
            if(_origin!=null) {
                HttpResponseMessageProperty _props = null;
                if(reply.Properties.ContainsKey(HttpResponseMessageProperty.Name)) {
                    _props=reply.Properties[HttpResponseMessageProperty.Name] as HttpResponseMessageProperty;
                } else {
                    _props=new HttpResponseMessageProperty();
                    reply.Properties.Add(HttpResponseMessageProperty.Name,_props);
                }
                _props.Headers.Add("Access-Control-Allow-Origin",_origin);
                _props.Headers.Add("Access-Control-Allow-Credentials","true");
                _props.Headers.Add("Access-Control-Request-Method","POST,GET,OPTIONS");
                _props.Headers.Add("Access-Control-Allow-Headers","X-Requested-With,Content-Type");
            }
        }
    }
}
