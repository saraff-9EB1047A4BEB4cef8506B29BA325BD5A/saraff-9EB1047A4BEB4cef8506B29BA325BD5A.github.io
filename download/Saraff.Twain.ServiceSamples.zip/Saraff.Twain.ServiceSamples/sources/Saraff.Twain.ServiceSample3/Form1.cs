﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2016.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2016.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TwSvc = Saraff.Twain.ServiceSample3.TwainServiceReference;

namespace Saraff.Twain.ServiceSample3 {

    internal sealed partial class Form1:Form {
        private TwSvc.TwainServiceClient _svc = null;

        public Form1() {
            InitializeComponent();
            ((ComboBox)this.dsToolStripComboBox.Control).DataSource=this.dsBindingSource;
        }

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            try {
                this._Load();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void _Load() {
            this.toolStrip1.Enabled=false;
            this.Text=string.Format("{0} - Loading...",this.Name);
            this.dsBindingSource.DataSource=new string[] { "Loading..." };
            this.resolutionsToolStripDropDownButton.Text="Loading...";
            this.pixelTypesToolStripDropDownButton.Text="Loading...";
            this.TwainService.BeginGetSources(result => {
                try {
                    var _ds = this.TwainService.EndGetSources(result);
                    this.Invoke(new Action(() => {
                        this.dsBindingSource.DataSource=_ds;
                        this.dsBindingSource.Position=_ds.IndexOf(_ds.First(val => val.IsDefault));
                        this._LoadCaps();
                        this.dsBindingSource.CurrentChanged+=dsBindingSource_CurrentChanged;
                    }));
                } catch(Exception ex) {
                    this._ShowError(ex);
                }
            },null);
        }

        private void _LoadCaps() {
            var _ds = this.dsBindingSource.Current as TwSvc.Source;
            if(_ds!=null) {
                this.Text=string.Format("{0} - Loading Capabilities...",this.Name);
                this.toolStrip1.Enabled=false;
                this.resolutionsToolStripDropDownButton.Text="Loading...";
                this.pixelTypesToolStripDropDownButton.Text="Loading...";
                this.TwainService.BeginGetCaps(_ds,new Collection<TwSvc.TwCap> { TwSvc.TwCap.XResolution,TwSvc.TwCap.IPixelType },result => {
                    try {
                        var _caps = this.TwainService.EndGetCaps(result);
                        this.Invoke(new Action(() => {
                            this._Fill<float>(this.resolutionsToolStripDropDownButton,_caps.First(val => val.Cap==TwSvc.TwCap.XResolution));
                            this._Fill<TwPixelType>(this.pixelTypesToolStripDropDownButton,_caps.First(val => val.Cap==TwSvc.TwCap.IPixelType));
                            this.Text=this.Name;
                            this.toolStrip1.Enabled=true;
                        }));
                    } catch(Exception ex) {
                        this._ShowError(ex);
                    }
                },null);
            }
        }

        private void _Fill<TValue>(ToolStripDropDownButton control,TwSvc.CapEnum items) {
            control.DropDownItems.Clear();
            for(var i = 0; i<items.Values.Count; i++) {
                control.DropDownItems.Add(
                    items.Values[i].GetValue<TValue>().ToString(),
                    null,
                    (sender,e) => {
                        var _sender = sender as ToolStripItem;
                        if(_sender!=null) {
                            _sender.OwnerItem.Tag=_sender.Tag;
                            _sender.OwnerItem.Text=_sender.Text;
                        }
                    }).Tag=items.Values[i];
            }
            control.Text=items.Current.GetValue<TValue>().ToString();
            control.Tag=items.Current;
        }

        private void _Acquire() {
            var _ds = this.dsBindingSource.Current as TwSvc.Source;
            if(_ds!=null) {
                this.Text=string.Format("{0} - Acquiring...",this.Name);
                this.toolStrip1.Enabled=false;
                this.TwainService.BeginAcquire(
                    _ds,
                    new Collection<TwSvc.CapEnum> {
                        new TwSvc.CapEnum{Cap=TwSvc.TwCap.XResolution,Current=this.resolutionsToolStripDropDownButton.Tag as TwSvc.CapValue},
                        new TwSvc.CapEnum{Cap=TwSvc.TwCap.YResolution,Current=this.resolutionsToolStripDropDownButton.Tag as TwSvc.CapValue},
                        new TwSvc.CapEnum{Cap=TwSvc.TwCap.IPixelType,Current=this.pixelTypesToolStripDropDownButton.Tag as TwSvc.CapValue}},
                    result => {
                        try {
                            var _stream = this.TwainService.EndAcquire(result);
                            this.Invoke(new Action(() => {
                                this.CurrentImage=Image.FromStream(_stream);
                                this.Text=this.Name;
                                this.toolStrip1.Enabled=true;
                            }));
                        }catch(Exception ex) {
                            this._ShowError(ex);
                        }
                    },null);
            }
        }

        private void _Save() {
            if(this.saveFileDialog1.ShowDialog()==DialogResult.OK) {
                this.CurrentImage.Save(this.saveFileDialog1.FileName,ImageFormat.Jpeg);
            }
        }

        private void _ShowError(Exception ex) {
            var _msg = string.Empty;
            for(var _ex = ex; _ex!=null; _ex=_ex.InnerException) {
                _msg+=string.Format("{1}: {2}{0}{3}{0}{0}",Environment.NewLine,_ex.GetType().Name,_ex.Message,_ex.StackTrace);
            }
            var _action = new Action(() => MessageBox.Show(_msg,ex.GetType().Name,MessageBoxButtons.OK,MessageBoxIcon.Error));
            if(this.InvokeRequired) {
                this.Invoke(_action);
            } else {
                _action();
            }
        }

        private TwSvc.ITwainService TwainService {
            get {
                if(this._svc==null) {
                    this._svc=new TwSvc.TwainServiceClient();
                    this._svc.Open();
                }
                return this._svc;
            }
        }

        private Image CurrentImage {
            get {
                return this.pictureBox1.Image;
            }
            set {
                if(this.pictureBox1.Image!=null) {
                    this.pictureBox1.Image.Dispose();
                }
                this.pictureBox1.Image=value;
            }
        }

        private void newToolStripButton_Click(object sender,EventArgs e) {
            try {
                this._Acquire();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void saveToolStripButton_Click(object sender,EventArgs e) {
            try {
                this._Save();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }

        private void dsBindingSource_CurrentChanged(object sender,EventArgs e) {
            try {
                this._LoadCaps();
            } catch(Exception ex) {
                this._ShowError(ex);
            }
        }
    }
}
