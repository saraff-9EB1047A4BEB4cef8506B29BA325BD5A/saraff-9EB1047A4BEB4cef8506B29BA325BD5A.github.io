﻿/* Этот файл является частью примеров использования библиотеки Saraff.Twain.NET
 * © SARAFF SOFTWARE (Кирножицкий Андрей), 2011.
 * Saraff.Twain.NET - свободная программа: вы можете перераспространять ее и/или
 * изменять ее на условиях Меньшей Стандартной общественной лицензии GNU в том виде,
 * в каком она была опубликована Фондом свободного программного обеспечения;
 * либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
 * версии.
 * Saraff.Twain.NET распространяется в надежде, что она будет полезной,
 * но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
 * или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Меньшей Стандартной
 * общественной лицензии GNU.
 * Вы должны были получить копию Меньшей Стандартной общественной лицензии GNU
 * вместе с этой программой. Если это не так, см.
 * <http://www.gnu.org/licenses/>.)
 * 
 * This file is part of samples of Saraff.Twain.NET.
 * © SARAFF SOFTWARE (Kirnazhytski Andrei), 2011.
 * Saraff.Twain.NET is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * Saraff.Twain.NET is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with Saraff.Twain.NET. If not, see <http://www.gnu.org/licenses/>.
 * 
 * PLEASE SEND EMAIL TO:  twain@saraff.ru.
 */

/// <reference path="jquery-3.1.1.js" />

const _serviceUrl = "http://localhost:8081/twain-web/";

$(document).ready(function () {
    $("#notify").text("Get Sources...");
    $.getJSON(_serviceUrl + "GetSources", function (sources) {
        $("#notify").text("Ready.");
        $("#ds").empty();
        let _selected;
        $.each(sources, function (i, _ds) {
            let _item;
            $("#ds").append(_item = $("<option/>").attr("value", JSON.stringify(_ds)).text("[" + _versions[_ds.Version] + ", " + _platforms[_ds.Platform] + "] " + _ds.Name));
            if (_ds.IsDefault) {
                _selected = _item;
            }
        });

        $("#ds").val(_selected.prop("value"));
        $("#ds").change(function () {
            $("#toolstrip").children().prop("disabled", true);
            $("#notify").text("Get Capabilities...");
            let _ds = JSON.parse($(this).val());
            $.getJSON(
                _serviceUrl + "GetCaps",
                { platform: _platforms[_ds.Platform], version: _versions[_ds.Version], sourceId: _ds.Id, caps: "IPixelType,XResolution" },
                function (_caps) {
                    $("#notify").text("Ready.");
                    [$("#PixelType"), $("#dpi")].forEach(function (_combo) { _combo.empty(); });
                    let _notSupportedCaps = ["IPixelType", "XResolution"].filter(function (_cap) {
                        return !_caps.some(function (x) {
                            return _capabilities[x.Cap] === _cap;
                        });
                    });
                    if (_notSupportedCaps.length > 0) {
                        $("#notify").text("The DS does not support all required capabilities: " + _notSupportedCaps);
                    }
                    $.each(_caps, function (i, _cap) {
                        let _combo = { IPixelType: $("#PixelType"), XResolution: $("#dpi") }[_capabilities[_cap.Cap]];
                        if (_combo !== undefined) {
                            let _current;
                            $.each(_cap.Values, function (i, _val) {
                                let _item;
                                _combo.append(_item = $("<option/>").prop("value", JSON.stringify(_val.RawValue)).text(_capValues[_capabilities[_cap.Cap]](_val.Name)));
                                if (_cap.Current.Name===_val.Name) {
                                    _current = _item;
                                }
                            });
                            _combo.val(_current.prop("value"));
                        }
                    });
                }).fail(function () {
                    $("#notify").text("An error occurred during Get Capabilities.");
                }).always(function () {
                    $("#toolstrip").children().prop("disabled", false);
                });
        }).change();

        $("#acquire").click(function () {
            $("#toolstrip").children().prop("disabled", true);
            $("#notify").text("Acquire...");

            let _ds = JSON.parse($("#ds").val());
            $.getJSON(
                _serviceUrl + "Acquire",
                {
                    platform: _platforms[_ds.Platform],
                    version: _versions[_ds.Version],
                    sourceId: _ds.Id,
                    caps: JSON.stringify({
                        IPixelType: $("#PixelType").val(),
                        XResolution: $("#dpi").val(),
                        YResolution: $("#dpi").val()
                    })
                },
                function (_image) {
                    $("#notify").text("Ready.");
                    $("#image").prop("src", "data:image/jpeg;base64," + _image);
                    $("#image").data({ base64: _image });
                }).fail(function () {
                    $("#notify").text("An error occurred during Acquire.");
                }).always(function () {
                    $("#toolstrip").children().prop("disabled", false);
                });
        });

        $("#upload").click(function () {
            let _image = $("#image").data()["base64"];
            if (_image === undefined) {
                alert("The image does not acquired yet.");
                return;
            }
            $("#toolstrip").children().prop("disabled", true);
            $("#notify").text("uploading...");
            $.post("uploadhandler.ashx", { action: "create", ext: "jpg" }, function (filename) {
                let _append = function (position,blockSize) {
                    $("#notify").text("uploading... " + filename + " " + Math.round(position / _image.length * 100)+"%");
                    $.post("uploadhandler.ashx", { action: "append", name: filename, data: _image.substr(position, blockSize) })
                        .done(function () {
                            if (position + blockSize < _image.length) {
                                _append(position + blockSize, blockSize);
                            } else {
                                $("#toolstrip").children().prop("disabled", false);
                                $("#notify").text("uploaded. " + filename);
                            }
                        })
                        .fail(function () {
                            $("#toolstrip").children().prop("disabled", false);
                            $("#notify").text("upload failed. " + filename);
                        });
                };
                _append(0, 8 * 1024);
            }).fail(function () {
                $("#toolstrip").children().prop("disabled", false);
                $("#notify").text("upload failed.");
            });
        });
    }).fail(function () {
        $("#notify").text("An error occurred during Get Sources.");
    });
});

var _platforms = { 0: "X86_32", 1: "X86_64" };

var _versions = { 0: "V1", 1: "V2" };

var _capabilities = {
    0x0101: "IPixelType",
    0x1118: "XResolution"
};

var _capValues = {
    IPixelType: function (value) {
        return { 0: "BW", 1: "Gray", 2: "RGB", 3: "Palette", 4: "CMY", 5: "CMYK", 6: "YUV", 7: "YUVK", 8: "CIEXYZ", 9: "LAB", 10: "SRGB", 11: "SCRGB", 16: "INFRARED" }[value];
    },
    XResolution: function (value) {
        return value;
    }
};
