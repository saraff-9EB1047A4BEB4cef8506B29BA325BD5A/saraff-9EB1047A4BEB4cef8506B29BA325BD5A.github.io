﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;

namespace Saraff.IoC.Samples.SimpleApp.Core {

    public abstract class Bulb : Component, IBulb {

        public virtual string GetSpecification() {
            return $"Bulb; Code: {this.Code}; Type: {this.Type};";
        }

        public abstract string Code {
            get;
        }

        public abstract string Type {
            get;
        }
    }
}
