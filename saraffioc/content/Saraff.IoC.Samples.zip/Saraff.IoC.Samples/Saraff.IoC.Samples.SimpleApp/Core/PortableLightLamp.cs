﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;

namespace Saraff.IoC.Samples.SimpleApp.Core {

    public sealed class PortableLightLamp : Lamp {
        private IEnumerable<IBulb> _bulbs;

        [IoC.ServiceRequired]
        public PortableLightLamp(IBulb blub) {
            this._bulbs = new IBulb[] { blub, blub, blub };
        }

        public override string Name => "Flexible Portable Travel Book Reading Light Lamp Mini LED Clip Booklight+Battery";

        public override string Type => "Portable";

        public override string Brand => "Unbranded";

        public override string Material => "-";

        public override IEnumerable<IBulb> Bulbs => this._bulbs;
    }
}
