﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;

namespace Saraff.IoC.Samples.SimpleApp.Core {

    public sealed class HalogenBulb : Bulb {

        public override string GetSpecification() {
            return $"{base.GetSpecification()} 230V; 30W;";
        }

        public override string Code => "E14";

        public override string Type => "Halogen";
    }
}
