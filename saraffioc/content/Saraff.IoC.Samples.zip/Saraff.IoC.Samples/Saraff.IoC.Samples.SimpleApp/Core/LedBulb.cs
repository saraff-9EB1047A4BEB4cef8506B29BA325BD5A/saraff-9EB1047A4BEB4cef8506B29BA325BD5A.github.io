﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;

namespace Saraff.IoC.Samples.SimpleApp.Core {

    public sealed class LedBulb : Bulb {

        public override string GetSpecification() {
            return $"{base.GetSpecification()} 7W; 560 lm;";
        }

        public override string Code => "E27";

        public override string Type => "LED";
    }
}
