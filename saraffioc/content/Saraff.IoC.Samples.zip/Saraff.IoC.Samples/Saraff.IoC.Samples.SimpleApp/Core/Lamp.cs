﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;

namespace Saraff.IoC.Samples.SimpleApp.Core {

    public abstract class Lamp : Component, ILamp {

        public virtual string GetSpecification() {
            var _bulbsSpecification = string.Empty;
            foreach(var _bulb in this.Bulbs) {
                _bulbsSpecification += $"{Environment.NewLine}    {_bulb.GetSpecification()}";
            }
            return $"Lamp; Name: {this.Name}; Type: {this.Type}; Brand: {this.Brand}; Material: {this.Material};{Environment.NewLine}Bulbs:{Environment.NewLine}    Count: {this.Bulbs.Count()};{_bulbsSpecification}";
        }

        public abstract string Name {
            get;
        }

        public abstract string Type {
            get;
        }

        public abstract string Brand {
            get;
        }

        public abstract string Material {
            get;
        }

        public abstract IEnumerable<IBulb> Bulbs {
            get;
        }
    }
}
