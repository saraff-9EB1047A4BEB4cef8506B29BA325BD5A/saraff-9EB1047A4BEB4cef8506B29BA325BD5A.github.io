﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.SimpleApp.Core {

    public sealed class GlassDeskLamp : Lamp {
        private IEnumerable<IBulb> _bulbs;

        [IoC.ServiceRequired]
        public GlassDeskLamp(IBulb blub) {
            this._bulbs = new IBulb[] { blub, blub, blub, blub, blub, blub, blub };
        }

        public override string Name => "Magnifying Crafts Glass Desk Lamp With 5X 10X Magnifier 40 LED Lighting AU Plug";

        public override string Type => "Desk";

        public override string Brand => "Unbranded";

        public override string Material => "Plastic";

        public override IEnumerable<IBulb> Bulbs => this._bulbs;
    }
}
