﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.SimpleApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.SimpleApp {

    internal sealed class Program {

        private static void Main(string[] args) {
            try {
                using(var _container = new IoC.ServiceContainer()) {
                    _container.Bind<IBulb, Core.LedBulb>();

                    Console.WriteLine(_container.CreateInstance<Core.GlassDeskLamp>().GetSpecification());
                    Console.WriteLine();

                    _container.Bind<IContextBinder<IBulb, Core.GlassDeskLamp>, Core.HalogenBulb>();

                    Console.WriteLine(_container.CreateInstance<Core.GlassDeskLamp>().GetSpecification());
                    Console.WriteLine();
                    Console.WriteLine(_container.CreateInstance<Core.PortableLightLamp>().GetSpecification());

                }
            } catch(Exception ex) {
                Program._ToLog(ex);
            }
        }

        private static void _ToLog(Exception ex) {
            Debug.WriteLine("=== BEGIN EXCEPTION ===");
            Debug.WriteLine(string.Empty);
            for(var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Debug.WriteLine($"{_ex.GetType().FullName}: {_ex.Message}");
                Debug.WriteLine(_ex.StackTrace);
                Debug.WriteLine(string.Empty);
            }
            Debug.WriteLine("=== END EXCEPTION ===");
        }
    }
}
