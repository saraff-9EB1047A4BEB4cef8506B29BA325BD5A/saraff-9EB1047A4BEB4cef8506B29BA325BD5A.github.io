﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saraff.IoC.Samples.SimpleApp.ComponentModel {

    public interface IBulb : IArtifact {

        string Code {
            get;
        }

        string Type {
            get;
        }
    }
}
