﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saraff.IoC.Samples.SimpleApp.ComponentModel {

    public interface ILamp : IArtifact {

        string Name {
            get;
        }

        string Type {
            get;
        }

        string Brand {
            get;
        }

        string Material {
            get;
        }

        IEnumerable<IBulb> Bulbs {
            get;
        }
    }
}
