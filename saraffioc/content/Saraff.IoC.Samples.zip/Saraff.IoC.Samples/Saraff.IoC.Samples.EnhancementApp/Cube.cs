﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.EnhancementApp {

    internal sealed class Cube : Geo {

        [IoC.ServiceRequired]
        public Cube(decimal x, decimal y, decimal z) {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        protected override decimal GetVolum() => this.X * this.Y * this.Z;

        public decimal X {
            get;
            private set;
        }

        public decimal Y {
            get;
            private set;
        }

        public decimal Z {
            get;
            private set;
        }
    }
}
