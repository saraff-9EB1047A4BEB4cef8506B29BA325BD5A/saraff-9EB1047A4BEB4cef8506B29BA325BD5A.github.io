﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saraff.IoC.Samples.EnhancementApp.ComponentModel {

    public interface IAir {

        decimal GetDensity {
            get;
        }
    }
}
