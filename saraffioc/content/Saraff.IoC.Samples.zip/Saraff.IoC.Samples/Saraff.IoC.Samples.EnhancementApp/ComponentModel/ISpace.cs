﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saraff.IoC.Samples.EnhancementApp.ComponentModel {

    public interface ISpace {

        decimal GetWeight(decimal volume, IAir air = null);
    }
}
