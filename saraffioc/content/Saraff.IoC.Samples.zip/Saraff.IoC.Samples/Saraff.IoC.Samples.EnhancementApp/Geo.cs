﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.EnhancementApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.EnhancementApp {

    internal abstract class Geo {

        protected abstract decimal GetVolum();

        public decimal GetWeight() => this.Space?.GetWeight(this.GetVolum()) ?? 0M;

        [IoC.ServiceRequired]
        public ISpace Space {
            get; set;
        }
    }
}
