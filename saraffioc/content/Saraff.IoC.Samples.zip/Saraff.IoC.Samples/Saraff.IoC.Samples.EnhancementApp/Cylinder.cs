﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.EnhancementApp {

    internal sealed class Cylinder : Geo {

        [IoC.ServiceRequired]
        public Cylinder(decimal r, decimal h) {
            this.R = r;
            this.H = h;
        }

        protected override decimal GetVolum() => (decimal)Math.PI * this.R * this.R * this.H;

        public decimal R {
            get;
            private set;
        }

        public decimal H {
            get;
            private set;
        }
    }
}
