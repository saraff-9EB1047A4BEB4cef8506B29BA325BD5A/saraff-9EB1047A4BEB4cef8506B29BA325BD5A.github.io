using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.EnhancementApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.EnhancementApp.Core {

    [IoC.ProxyRequired]
    internal sealed class Space : Component, ISpace {

        public decimal GetWeight(decimal volume, [IoC.ServiceRequired] IAir air = null) => volume * air?.GetDensity ?? 0m;
    }
}