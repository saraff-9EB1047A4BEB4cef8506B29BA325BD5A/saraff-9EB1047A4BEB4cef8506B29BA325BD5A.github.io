using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.EnhancementApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.EnhancementApp.Core {

    internal sealed class StrongAir : Component, IAir {

        public decimal GetDensity => 20m;
    }
}