﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.EnhancementApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.EnhancementApp {

    internal sealed class Program {

        private static void Main(string[] args) {
            try {
                using(var _container = new IoC.ServiceContainer()) {
                    _container.Bind<ISpace, Core.Space>();
                    _container.Bind<IAir, Core.NormalAir>();

                    Console.WriteLine("NormalAir:");
                    Console.WriteLine($"Cylinder = {_container.CreateInstance<Cylinder>(x => x("h", 10m), x => x("r", 5m)).GetWeight()}");
                    Console.WriteLine($"Cube = {_container.CreateInstance<Cube>(x => x("x", 4m), x => x("y", 6m), x => x("z", 7m)).GetWeight()}");

                    _container.Bind<IoC.IContextBinder<IAir, Core.Space>, Core.StrongAir>();
                    Console.WriteLine("StrongAir:");
                    Console.WriteLine($"Cylinder = {_container.CreateInstance<Cylinder>(x => x("h", 10m), x => x("r", 5m)).GetWeight()}");
                    Console.WriteLine($"Cube = {_container.CreateInstance<Cube>(x => x("x", 4m), x => x("z", 7m), x => x("y", 6m)).GetWeight()}");

                }
            } catch(Exception ex) {
                Program._ToLog(ex);
            }
        }

        private static void _ToLog(Exception ex) {
            Debug.WriteLine("=== BEGIN EXCEPTION ===");
            Debug.WriteLine(string.Empty);
            for(var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Debug.WriteLine($"{_ex.GetType().FullName}: {_ex.Message}");
                Debug.WriteLine(_ex.StackTrace);
                Debug.WriteLine(string.Empty);
            }
            Debug.WriteLine("=== END EXCEPTION ===");
        }
    }
}
