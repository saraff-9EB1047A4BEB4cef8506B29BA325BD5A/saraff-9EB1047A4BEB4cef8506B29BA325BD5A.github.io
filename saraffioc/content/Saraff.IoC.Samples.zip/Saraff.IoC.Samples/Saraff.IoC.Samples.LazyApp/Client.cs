﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.LazyApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.LazyApp {

    internal sealed class Client {

        public string Execute() => $"DateTimeService.ToLongTimeString() = {this.DateTimeService()?.Cyclical().ToLongTimeString()}; StreamService.ToString() = {this.StreamService()?.Cyclical().ToString()}";

        public string Execute2() => $"DateTimeService.ToLongTimeString() = {this.DateTimeService()?.Cyclical2().ToLongTimeString()}; StreamService.ToString() = {this.StreamService()?.Cyclical2().ToString()}";

        [IoC.ServiceRequired]
        public IoC.Lazy<IService<DateTime>> DateTimeService {
            get;
            set;
        }

        [IoC.ServiceRequired]
        public IoC.Lazy<IService<MemoryStream>> StreamService {
            get;
            set;
        }
    }
}
