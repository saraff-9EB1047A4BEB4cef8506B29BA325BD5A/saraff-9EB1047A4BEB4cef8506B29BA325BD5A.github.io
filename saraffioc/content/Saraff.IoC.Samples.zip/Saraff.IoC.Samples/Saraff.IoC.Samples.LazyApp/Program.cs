﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.LazyApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.LazyApp {

    internal sealed class Program {

        private static void Main(string[] args) {
            try {
                using(var _container = new IoC.ServiceContainer()) {
                    _container.Bind<IService<DateTime>, Core.DateTimeService>();
                    _container.Bind<IService<MemoryStream>, Core.GenericService<MemoryStream>>();

                    var _client = _container.CreateInstance<Client>();
                    Console.WriteLine($"Client.Execute = {_client.Execute()}");
                    Console.WriteLine();
                    Console.WriteLine($"Client.Execute2 = {_client.Execute2()}");
                }
            } catch(Exception ex) {
                Program._ToLog(ex);
            }
        }

        private static void _ToLog(Exception ex) {
            Debug.WriteLine("=== BEGIN EXCEPTION ===");
            Debug.WriteLine(string.Empty);
            for(var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Debug.WriteLine($"{_ex.GetType().FullName}: {_ex.Message}");
                Debug.WriteLine(_ex.StackTrace);
                Debug.WriteLine(string.Empty);
            }
            Debug.WriteLine("=== END EXCEPTION ===");
        }
    }
}
