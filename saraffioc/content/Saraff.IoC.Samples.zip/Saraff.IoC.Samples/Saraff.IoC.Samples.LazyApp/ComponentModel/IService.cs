﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saraff.IoC.Samples.LazyApp.ComponentModel {

    public interface IService<T> {

        T GetAnything();

        T Cyclical();

        T Cyclical2(IService<T> svc = null);
    }
}
