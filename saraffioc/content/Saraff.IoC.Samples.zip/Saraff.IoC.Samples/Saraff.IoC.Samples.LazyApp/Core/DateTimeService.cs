﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.LazyApp.ComponentModel;

namespace Saraff.IoC.Samples.LazyApp.Core {

    [IoC.ProxyRequired]
    internal sealed class DateTimeService : Component, IService<DateTime> {

        public DateTimeService() {
        }

        public DateTime Cyclical() => this.Svc()?.GetAnything() ?? DateTime.MinValue;

        public DateTime Cyclical2([IoC.ServiceRequired]IService<DateTime> svc = null) => svc?.GetAnything() ?? DateTime.MinValue;

        public DateTime GetAnything() => DateTime.Now;

        [IoC.ServiceRequired]
        public IoC.Lazy<IService<DateTime>> Svc {
            get;
            set;
        }
    }
}
