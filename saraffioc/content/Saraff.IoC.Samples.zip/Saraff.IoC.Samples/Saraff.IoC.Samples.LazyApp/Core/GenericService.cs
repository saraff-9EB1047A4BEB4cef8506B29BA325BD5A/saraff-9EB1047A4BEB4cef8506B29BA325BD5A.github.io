﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.LazyApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.LazyApp.Core {

    [IoC.ProxyRequired]
    internal sealed class GenericService<T> : Component, IService<T> where T : class, new() {

        public GenericService() {
        }

        public T Cyclical() => this.Svc()?.GetAnything();

        public T Cyclical2([IoC.ServiceRequired]IService<T> svc = null) => svc?.GetAnything();

        public T GetAnything() => new T();

        [IoC.ServiceRequired]
        public IoC.Lazy<IService<T>> Svc {
            get;
            set;
        }
    }
}
