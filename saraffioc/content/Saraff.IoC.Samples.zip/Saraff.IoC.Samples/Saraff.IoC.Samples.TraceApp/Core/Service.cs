﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.TraceApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.TraceApp.Core {

    [IoC.ProxyRequired]
    internal sealed class Service : Component, IService {

        public T GetAnything<T>() where T : new() {
            return new T();
        }

        public void ThrowException<T>() where T : Exception, new() {
            throw new T();
        }
    }
}
