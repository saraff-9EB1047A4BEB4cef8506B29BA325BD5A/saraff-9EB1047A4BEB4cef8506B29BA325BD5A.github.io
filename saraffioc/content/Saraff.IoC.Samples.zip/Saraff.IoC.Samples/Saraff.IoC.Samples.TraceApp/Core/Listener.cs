﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.TraceApp.Core {

    internal sealed class Listener : Component, IoC.IListener {

        public object OnInvoking(MethodBase method, object instance, object[] parameters) {
            var _args = string.Empty;
            foreach(var _arg in parameters) {
                _args += $"{_arg?.ToString()}; ";
            }
            Program._ToLog($"Invoking: {method.ReflectedType.FullName}.{method.Name}; args = {{{_args}}}");
            return null;
        }

        public object OnInvoked(MethodBase method, object instance, object result) {
            Program._ToLog($"Invoked: {method.ReflectedType.FullName}.{method.Name}; result = {result}");
            return null;
        }

        public Exception OnCatch(MethodBase method, object instance, Exception ex) {
            Program._ToLog($"Catch exception: {method.ReflectedType.FullName}.{method.Name}; Exception = {ex.GetType().Name}");
            Program._ToLog(ex);
            return new ApplicationException("Catch exception.", ex);
        }
    }
}
