﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saraff.IoC.Samples.TraceApp.ComponentModel {

    public interface IService {

        T GetAnything<T>() where T : new();

        void ThrowException<T>() where T : Exception, new();
    }
}
