﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.TraceApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.TraceApp {

    internal sealed class Client {

        [IoC.ServiceRequired]
        public Client(IService svc) {
            svc.GetAnything<decimal>();
            svc.GetAnything<DateTime>();
            svc.GetAnything<MemoryStream>();
            svc.ThrowException<InvalidOperationException>();
        }
    }
}
