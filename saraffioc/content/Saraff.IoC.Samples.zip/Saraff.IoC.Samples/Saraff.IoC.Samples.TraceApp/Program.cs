﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Saraff.IoC.Samples.TraceApp.ComponentModel;
using IoC = Saraff.IoC;

namespace Saraff.IoC.Samples.TraceApp {

    internal sealed class Program {

        private static void Main(string[] args) {
            try {
                using(var _container = new IoC.ServiceContainer()) {
                    _container.Bind<IoC.IListener, Core.Listener>();
                    _container.Bind<IService, Core.Service>();

                    _container.CreateInstance<Client>();
                }
            } catch(Exception ex) {
                Program._ToLog(ex);
            }
        }

        internal static void _ToLog(string message) {
            Console.WriteLine(message);
        }

        internal static void _ToLog(Exception ex) {
            Console.WriteLine("=== BEGIN EXCEPTION ===");
            Console.WriteLine(string.Empty);
            for(var _ex = ex; _ex != null; _ex = _ex.InnerException) {
                Console.WriteLine($"{_ex.GetType().FullName}: {_ex.Message}");
                Console.WriteLine(_ex.StackTrace);
                Console.WriteLine(string.Empty);
            }
            Console.WriteLine("=== END EXCEPTION ===");
        }
    }
}
