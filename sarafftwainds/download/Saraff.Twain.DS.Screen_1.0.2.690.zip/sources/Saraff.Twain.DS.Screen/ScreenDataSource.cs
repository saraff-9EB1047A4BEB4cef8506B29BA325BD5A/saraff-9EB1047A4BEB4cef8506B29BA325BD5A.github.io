﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Saraff.Twain.DS.BitmapSource;
using Saraff.Twain.DS.Capabilities;
using Saraff.Twain.DS.Screen.ComponentModel;

namespace Saraff.Twain.DS.Screen {

    /// <summary>
    /// Provide a Data Source that controls the screen acquisition and is written by the device developer to
    /// comply with TWAIN specifications.
    /// </summary>
    /// <seealso cref="Saraff.Twain.DS.BitmapSource.BitmapDataSource" />
    [Guid("9D171477-A70C-4CB0-B223-4C941677D7E5")]
    //[Compression(/*TwCompression.Jpeg*//*,TwCompression.Png, ... */)] //ICAP_COMPRESSION (CompressionAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[LsbFirstSupported] //ICAP_BITORDER (LsbFirstSupportedAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [DeviceProperties(
        16f, //ICAP_PHYSICALWIDTH (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
        9f, //ICAP_PHYSICALHEIGHT (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
        96f, //ICAP_XNATIVERESOLUTION (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
        96f)] //ICAP_YNATIVERESOLUTION (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [PlanarChunky(TwPC.Chunky, DefaultValue = TwPC.Chunky)] //ICAP_PLANARCHUNKY (PlanarChunkyAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [PixelFlavor(TwPF.Chocolate)] //ICAP_PIXELFLAVOR (PixelFlavorAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [PixelType(TwPixelType.RGB, DefaultValue = TwPixelType.RGB)] //ICAP_PIXELTYPE (PixelTypeAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    #region When ICAP_PIXELTYPE supported TWPT_BW (TwPixelType.BW) value
    //[BitDepthReduction(TwBR.Threshold, TwBR.Diffusion)] //ICAP_BITDEPTHREDUCTION (BitDepthReductionAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[Halftones("A1","A2","A3")] //ICAP_HALFTONES (HalftonesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[CustHalftone(...)] //ICAP_CUSTHALFTONE (CustHalftoneAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[Threshold(128f)] //ICAP_THRESHOLD (ThresholdAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    #endregion
    [XferMech(File = true)/*ICAP_XFERMECH*/, MemXferBufferSize(64*1024U /*64K*/)/*TW_SETUPMEMXFER.Preferred on DG_CONTROL / DAT_SETUPMEMXFER / MSG_GET operation*/]
    [ImageFileFormat(TwFF.Bmp,TwFF.Tiff,TwFF.Jfif)] //ICAP_IMAGEFILEFORMAT (ImageFileFormatAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [Capability(typeof(Capabilities.DeviceOnlineDataSourceCapability))]
    [Capability(typeof(Capabilities.XResolutionDataSourceCapability))]
    [Capability(typeof(Capabilities.YResolutionDataSourceCapability))]
    [Capability(typeof(Capabilities.BitDepthDataSourceCapability))]
    [Capability(typeof(Capabilities.FeederXferCountDataSourceCapability))]
    public sealed class ScreenDataSource:BitmapDataSource {
        private Forms.AcquireForm _acquireForm;

        /// <summary>
        /// Gets or sets the current image layout.
        /// </summary>
        /// <value>
        /// The current image layout.
        /// </value>
        /// <exception cref="System.ArgumentException"></exception>
        protected override RectangleF CurrentImageLayout {
            get => base.CurrentImageLayout;
            set {
                if(value.Right > this.DefaultImageLayout.Right || value.Bottom > this.DefaultImageLayout.Bottom) {
                    throw new ArgumentException();
                }
                base.CurrentImageLayout = value;
            }
        }

        /// <summary>
        /// Gets the default image layout.
        /// </summary>
        /// <value>
        /// The default image layout.
        /// </value>
        protected override RectangleF DefaultImageLayout => this.ScreenService.BoundsF;

        /// <summary>
        /// If showUI is <c>true</c>, the Source should display its user interface and wait for
        /// the user to initiate an acquisition. If showUI is <c>false</c>,the Source should
        /// immediately begin acquiring data based on its current configuration (a device that requires the
        /// user to push a button on the device,such as a hand-scanner,will be “armed” by this operation and
        /// will assert MSG_XFERREADY as soon as the Source has data ready for transfer). The Source should
        /// fail any attempt to set a capability value (TWRC_FAILURE / TWCC_SEQERROR) until it returns to
        /// State 4 (unless an exception approval exists via a CAP_EXTENDEDCAPS agreement).
        /// Note: If the application has set showUI or CAP_INDICATORS to <c>true</c>, then the Source is
        /// responsible for presenting the user with appropriate progress indicators regarding the
        /// acquisition and transfer process. If showUI is set to <c>true</c>, CAP_INDICATORS is ignored
        /// and progress and errors are always shown.
        /// Note: It is strongly recommended that all Sources support being enabled without their User
        /// Interface if the application requests (showUI = <c>false</c>). But if your
        /// Source cannot be used without its User Interface, it should enable showing the Source
        /// User Interface (just as if showUI = <c>true</c>) but return TWRC_CHECKSTATUS. All Sources,
        /// however, must support the CAP_UICONTROLLABLE. This capability reports whether or
        /// not a Source allows showUI = <c>false</c>. An application can use this capability to know
        /// whether the Source-supplied user interface can be suppressed before it is displayed.
        /// </summary>
        /// <param name="showUI"><c>true</c> if DS should bring up its UI.</param>
        /// <param name="modalUI"><c>true</c> if the DS's UI is modal.</param>
        /// <param name="hwnd">For windows only - Application window handle.</param>
        protected override void OnEnableDS(bool showUI,bool modalUI,IntPtr hwnd) {
            if(showUI) {
                this._acquireForm = this.Factory.CreateInstance<Forms.AcquireForm>();
                this._acquireForm.FormClosed += (sender, e) => this.OnCloseDSReq();
                this._acquireForm.AcquireCallback += (sender, e) => this.OnXferReady();
                this._acquireForm.Show();
            } else {
                this.OnXferReady();
            }

            base.OnEnableDS(showUI,modalUI,hwnd);
        }

        /// <summary>
        /// If the Source’s user interface is displayed, it should be lowered. The Source returns to State 4 and
        /// is again available for capability negotiation.
        /// </summary>
        /// <param name="hwnd">For windows only - Application window handle.</param>
        protected override void OnDisableDS(IntPtr hwnd) {
            this._acquireForm?.Dispose();
            this._acquireForm = null;

            base.OnDisableDS(hwnd);
        }

        /// <summary>
        /// Invoked to indicate that the Source has data that is ready to be transferred.
        /// </summary>
        protected override void OnXferReady() {
            if((bool)this[TwCap.FeederEnabled].Value && (short)this[(TwCap)0x8001].Value > 0) {
                if((short)this[TwCap.XferCount].Value > 0) {
                    this.XferEnvironment.PendingXfers = Math.Min((ushort)(short)this[TwCap.XferCount].Value, (ushort)(short)this[(TwCap)0x8001].Value);
                } else {
                    this.XferEnvironment.PendingXfers = (ushort)(short)this[(TwCap)0x8001].Value;
                }
                this[(TwCap)0x8001].Value = (short)-1;
            }
            base.OnXferReady();
        }

        /// <summary>
        /// Acquire bitmap image.
        /// </summary>
        /// <returns>
        /// The bitmap image.
        /// </returns>
        protected override Bitmap Acquire() {
            var _depth = (ushort)this[TwCap.BitDepth].Value;
            var _format = PixelFormat.Undefined;

            switch((TwPixelType)this[TwCap.IPixelType].Value) {
                case TwPixelType.RGB:
                    _format=new Dictionary<ushort,PixelFormat> {
                        {24, PixelFormat.Format24bppRgb},
                        {48, PixelFormat.Format48bppRgb}}[_depth];
                    break;
            }

            using(var _coreImage = new Bitmap(this.ScreenService.Bounds.Width,this.ScreenService.Bounds.Height,_format)) {
                using(var _graphics = Graphics.FromImage(_coreImage)) {
                    _graphics.CopyFromScreen(this.ScreenService.Bounds.Location,this.ScreenService.Bounds.Location,this.ScreenService.Bounds.Size);
                }

                var _xdpi = (float)this[TwCap.XResolution].Value;
                var _ydpi = (float)this[TwCap.YResolution].Value;
                var _image = new Bitmap(
                    (int)(this.ScreenService.Bounds.Width*_xdpi/this.ScreenService.Resolution),
                    (int)(this.ScreenService.Bounds.Height*_ydpi/this.ScreenService.Resolution),
                    _format);
                _image.SetResolution(_xdpi,_ydpi);
                using(var _graphics = Graphics.FromImage(_image)) {
                    _graphics.DrawImage(_coreImage,new Rectangle(new Point(),_image.Size),new Rectangle(new Point(),_coreImage.Size),GraphicsUnit.Pixel);
                }
                return _image;
            }
        }

        [IoC.ServiceRequired]
        public IScreenService ScreenService { get; set; }
    }
}
