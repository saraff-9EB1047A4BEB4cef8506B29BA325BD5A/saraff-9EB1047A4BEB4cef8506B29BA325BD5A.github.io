﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Capabilities;

namespace Saraff.Twain.DS.Screen.Capabilities {

    [DataSourceCapability(CapId, TwType.Int16, SupportedOperations=TwQC.Get|TwQC.GetCurrent|TwQC.GetDefault|TwQC.Set, Get=TwOn.One)]
    internal sealed class FeederXferCountDataSourceCapability:OneDataSourceCapability<short> {
        public const TwCap CapId = (TwCap)0x8001;
    }
}
