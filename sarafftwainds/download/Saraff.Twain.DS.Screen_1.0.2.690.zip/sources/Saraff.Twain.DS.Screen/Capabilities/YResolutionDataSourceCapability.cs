﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Capabilities;

namespace Saraff.Twain.DS.Screen.Capabilities {

    //ICAP_YRESOLUTION All MSG_* operations required
    [DataSourceCapability(TwCap.YResolution, TwType.Fix32, SupportedOperations = TwQC.Get | TwQC.GetCurrent | TwQC.GetDefault | TwQC.Set | TwQC.Reset, Get = TwOn.Enum)]
    internal sealed class YResolutionDataSourceCapability : EnumDataSourceCapability<float> {

        public YResolutionDataSourceCapability() {
            this.CurrentIndexCore = this.DefaultIndexCore;
        }

        protected override Collection<float> CoreValues => new Collection<float> { 75f, 96f, 100f, 150, 200f, 300f, 600f };

        protected override int DefaultIndexCore => 1;
    }
}
