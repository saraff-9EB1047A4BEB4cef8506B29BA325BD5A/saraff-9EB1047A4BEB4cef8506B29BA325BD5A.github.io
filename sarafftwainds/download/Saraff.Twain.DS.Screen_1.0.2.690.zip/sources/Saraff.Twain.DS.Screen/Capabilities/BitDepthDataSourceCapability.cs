﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Capabilities;
using Saraff.Twain.DS.Screen.ComponentModel;

namespace Saraff.Twain.DS.Screen.Capabilities {

    //ICAP_BITDEPTH All MSG_* operations required
    [DataSourceCapability(TwCap.BitDepth, TwType.UInt16, SupportedOperations = TwQC.Get | TwQC.GetCurrent | TwQC.GetDefault | TwQC.Set | TwQC.Reset, Get = TwOn.Enum)]
    internal sealed class BitDepthDataSourceCapability : EnumDataSourceCapability<ushort> {

        protected override Collection<ushort> CoreValues => new Collection<ushort> { 24 };

        protected override int DefaultIndexCore => 0;

        public IEnumerable<ushort> BitDepthValues => this.CoreValues;
    }
}
