﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Capabilities;

namespace Saraff.Twain.DS.Screen.Capabilities {

    //ICAP_XRESOLUTION All MSG_* operations required
    [DataSourceCapability(TwCap.XResolution, TwType.Fix32, SupportedOperations = TwQC.Get | TwQC.GetCurrent | TwQC.GetDefault | TwQC.Set | TwQC.Reset, Get = TwOn.Enum)]
    internal sealed class XResolutionDataSourceCapability : EnumDataSourceCapability<float> {

        public XResolutionDataSourceCapability() {
            this.CurrentIndexCore = this.DefaultIndexCore;
        }

        protected override Collection<float> CoreValues => new Collection<float> { 75f, 96f, 100f, 150, 200f, 300f, 600f };

        protected override int DefaultIndexCore => 1;

        public IEnumerable<float> XResolutionValues => this.CoreValues;
    }
}
