﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Capabilities;
using Saraff.Twain.DS.Screen.ComponentModel;

namespace Saraff.Twain.DS.Screen.Capabilities {

    //CAP_DEVICEONLINE MSG_GET required
    [DataSourceCapability(TwCap.DeviceOnline, TwType.Bool, SupportedOperations = TwQC.Get | TwQC.GetCurrent | TwQC.GetDefault, Get = TwOn.Enum)]
    internal sealed class DeviceOnlineDataSourceCapability : EnumDataSourceCapability<bool> {

        #region EnumDataSourceCapability

        protected override Collection<bool> CoreValues => new Collection<bool> { this.Device?.IsOnline ?? false };

        protected override int CurrentIndexCore => 0;

        protected override int DefaultIndexCore => 0;

        #endregion

        [IoC.ServiceRequired]
        public IScreenService Device { get; set; }

    }
}
