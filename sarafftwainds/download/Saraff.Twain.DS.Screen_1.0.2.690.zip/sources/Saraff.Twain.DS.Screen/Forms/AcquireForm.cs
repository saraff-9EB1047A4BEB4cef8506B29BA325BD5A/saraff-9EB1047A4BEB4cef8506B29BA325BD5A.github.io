﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Saraff.Twain.DS.Screen.Forms {

    internal sealed partial class AcquireForm : Form {

        public AcquireForm() {
            this.InitializeComponent();
        }

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            try {
                var _xdpi = this.DS[TwCap.XResolution] as Capabilities.XResolutionDataSourceCapability;
                this.resolutionBindingSource.DataSource = _xdpi.XResolutionValues;
                this.resolutionBindingSource.Position = this.resolutionBindingSource.IndexOf(_xdpi.Value);
                this.resolutionBindingSource.CurrentChanged += this._ResolutionCurrentChanged;

                var _pixelType = (TwPixelType)this.DS[TwCap.IPixelType].Value;
                this.pixelTypeBindingSource.DataSource = new TwPixelType[] { _pixelType };
                this.pixelTypeBindingSource.Position = this.pixelTypeBindingSource.IndexOf(_pixelType);
                this.pixelTypeBindingSource.CurrentChanged += this._PixelTypeCurrentChanged;

                this.feederCheckBox.Checked = (bool)this.DS[TwCap.FeederEnabled].Value;
                this.xferCountNumericUpDown.Value = Math.Abs((short)this.DS[TwCap.XferCount].Value);

                var _depth = this.DS[TwCap.BitDepth] as Capabilities.BitDepthDataSourceCapability;
                this.bitDepthBindingSource.DataSource = _depth.BitDepthValues;
                this.bitDepthBindingSource.Position = this.bitDepthBindingSource.IndexOf(_depth.Value);
                this.bitDepthBindingSource.CurrentChanged += _BitDepthCurrentChanged;
            } catch(Exception ex) {
                this.Log.Write(ex);
            }
        }

        [IoC.ServiceRequired]
        public Extensions.ILog Log { get; set; }

        [IoC.ServiceRequired]
        public IDataSource DataSource { get; set; }

        private DataSource DS => this.DataSource as DataSource;

        private void OnAcquireRequred(EventArgs e) => this.AcquireCallback?.Invoke(this, e);

        private void _AcquireClick(object sender, EventArgs e) {
            try {
                this.OnAcquireRequred(EventArgs.Empty);
            } catch(Exception ex) {
                this.Log?.Write(ex);
            }
        }

        private void _FeederCheckedChanged(object sender, EventArgs e) {
            try {
                this.xferCountNumericUpDown.Enabled = this.feederCheckBox.Checked;
            } catch(Exception ex) { 
                this.Log?.Write(ex); 
            }
        }

        private void _ResolutionCurrentChanged(object sender, EventArgs e) {
            try {
                var _dpi = (float)this.resolutionBindingSource.Current;
                this.DS[TwCap.XResolution].Value = _dpi;
                this.DS[TwCap.YResolution].Value = _dpi;
            } catch(Exception ex) {
                this.Log?.Write(ex);
            }
        }

        private void _BitDepthCurrentChanged(object sender, EventArgs e) {
            try {
                this.DS[TwCap.BitDepth].Value = (ushort)this.bitDepthBindingSource.Current;
            } catch(Exception ex) {
                this.Log?.Write(ex);
            }
        }

        private void _PixelTypeCurrentChanged(object sender, EventArgs e) {
            try {
                this.DS[TwCap.IPixelType].Value = (TwPixelType)this.pixelTypeBindingSource.Current;
            } catch(Exception ex) {
                this.Log?.Write(ex);
            }
        }

        private void _XferCountValueChanged(object sender, EventArgs e) {
            try {
                this.DS[Capabilities.FeederXferCountDataSourceCapability.CapId].Value = (short)this.xferCountNumericUpDown.Value;
            } catch(Exception ex) {
                this.Log?.Write(ex);
            }
        }

        public event EventHandler AcquireCallback;
    }
}
