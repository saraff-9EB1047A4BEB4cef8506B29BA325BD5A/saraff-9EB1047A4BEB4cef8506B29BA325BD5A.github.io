﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Saraff.Twain.DS.Screen.ComponentModel {

    public interface IScreenService {

        bool IsOnline {
            get;
        }

        Rectangle Bounds {
            get;
        }

        RectangleF BoundsF {
            get;
        }

        float Resolution {
            get;
        }
    }
}
