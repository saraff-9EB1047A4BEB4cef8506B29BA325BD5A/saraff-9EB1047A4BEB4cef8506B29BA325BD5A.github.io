﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Screen.ComponentModel;

namespace Saraff.Twain.DS.Screen.Core {

    internal sealed class _ScreenService : Component, IScreenService {
        private System.Windows.Forms.Screen _screen = System.Windows.Forms.Screen.PrimaryScreen;

        public bool IsOnline => this._screen != null;

        public Rectangle Bounds => this._screen.Bounds;

        public RectangleF BoundsF => new RectangleF(this._screen.Bounds.X / this.Resolution, this._screen.Bounds.Y / this.Resolution, this._screen.Bounds.Width / this.Resolution, this._screen.Bounds.Height / this.Resolution);

        public float Resolution => 96f;
    }
}
