﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Saraff.Twain.DS.Extensions;

namespace Saraff.Twain.DS.Screen.Core {

    internal sealed class _Log : Component, Extensions.ILog {

        public void Write(Exception ex) {
            // <<<
        }

        public void Write(string message, LogLevel level = LogLevel.None) {
            // <<<
        }
    }
}
