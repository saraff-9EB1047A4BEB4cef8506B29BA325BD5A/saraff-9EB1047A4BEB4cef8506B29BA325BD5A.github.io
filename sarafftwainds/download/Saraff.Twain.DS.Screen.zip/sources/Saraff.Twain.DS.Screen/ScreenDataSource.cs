﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Saraff.Twain.DS.BitmapSource;
using Saraff.Twain.DS.Capabilities;

namespace Saraff.Twain.DS.Screen {

    /// <summary>
    /// Provide a Data Source that controls the screen acquisition and is written by the device developer to
    /// comply with TWAIN specifications.
    /// </summary>
    /// <seealso cref="Saraff.Twain.DS.BitmapSource.BitmapDataSource" />
    [Guid("9D171477-A70C-4CB0-B223-4C941677D7E5")]
    //[Compression(/*TwCompression.Jpeg*//*,TwCompression.Png, ... */)] //ICAP_COMPRESSION (CompressionAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[LsbFirstSupported] //ICAP_BITORDER (LsbFirstSupportedAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    /*[DeviceProperties(
        16f, //ICAP_PHYSICALWIDTH (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
        9f, //ICAP_PHYSICALHEIGHT (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
        100f, //ICAP_XNATIVERESOLUTION (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
        100f)] //ICAP_YNATIVERESOLUTION (DevicePropertiesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs)) */
    [PlanarChunky(TwPC.Chunky,DefaultValue = TwPC.Chunky)] //ICAP_PLANARCHUNKY (PlanarChunkyAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [PixelFlavor(TwPF.Chocolate)] //ICAP_PIXELFLAVOR (PixelFlavorAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [PixelType(TwPixelType.RGB,DefaultValue = TwPixelType.RGB)] //ICAP_PIXELTYPE (PixelTypeAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    #region When ICAP_PIXELTYPE supported TWPT_BW (TwPixelType.BW) value
    //[BitDepthReduction(TwBR.Threshold, TwBR.Diffusion)] //ICAP_BITDEPTHREDUCTION (BitDepthReductionAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[Halftones("A1","A2","A3")] //ICAP_HALFTONES (HalftonesAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[CustHalftone(...)] //ICAP_CUSTHALFTONE (CustHalftoneAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    //[Threshold(128f)] //ICAP_THRESHOLD (ThresholdAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    #endregion
    [XferMech(File = true)/*ICAP_XFERMECH*/, MemXferBufferSize(64*1024U /*64K*/)/*TW_SETUPMEMXFER.Preferred on DG_CONTROL / DAT_SETUPMEMXFER / MSG_GET operation*/]
    [ImageFileFormat(TwFF.Bmp,TwFF.Tiff,TwFF.Jfif)] //ICAP_IMAGEFILEFORMAT (ImageFileFormatAttribute or DataSource.OnCapabilityValueNeeded(CapabilityEventArgs))
    [Capability(typeof(Capabilities.FeederXferCountDataSourceCapability))]
    public sealed class ScreenDataSource:BitmapDataSource {
        private Dictionary<TwCap,DataSourceCapability> _caps = new Dictionary<TwCap,DataSourceCapability>();
        private Dictionary<TwCap,Action<DataSourceCapability>> _handlers = null;
        private readonly float _resolution = 96f;
        private System.Windows.Forms.Screen _screen;
        private Forms.AcquireForm _acquireForm;

        /// <summary>
        /// Initializes a new instance of the <see cref="ScreenDataSource"/> class.
        /// </summary>
        public ScreenDataSource() {
        }

        /// <summary>
        /// Invoked when the capability value need.
        /// </summary>
        /// <param name="e">Information about the capability that was changed.</param>
        protected override void OnCapabilityValueNeeded(CapabilityEventArgs e) {
            // #warning ICAP_BITDEPTH required
            // #warning ICAP_XRESOLUTION required
            // #warning ICAP_YRESOLUTION required
            // ICAP_UNITS optional (TwUnits.Inches default)
            for(var _cap = e.Capability.CapabilityInfo.Capability; this._Handlers.ContainsKey(_cap);) {
                this._Handlers[_cap](e.Capability);
                break;
            }

            // #warning CAP_DEVICEONLINE required
            switch(e.Capability.CapabilityInfo.Capability) {
                case TwCap.DeviceOnline:
                    e.Capability.Value=this._Screen!=null;
                    break;
            }

            #region When source supports Document Scanning using Fixed Frame Sizes

            //ICAP_SUPPORTEDSIZES required

            #endregion

            #region Document Feeders

            //CAP_FEEDERENABLED required
            //CAP_PAPERDETECTABLE required
            //CAP_AUTOFEED required

            #endregion

            #region When CAP_PAPERDETECTABLE value is TRUE

            //CAP_FEEDERLOADED required

            #endregion

            #region When CAP_AUTOFEED value is FALSE

            //CAP_EXTENDEDCAPS required
            //CAP_FEEDPAGE required
            //CAP_CLEARPAGE required
            //CAP_REWINDPAGE required

            #endregion

            #region When source supports duplex scanning

            //CAP_DUPLEX required
            //CAP_DUPLEXENABLED required

            #endregion

            #region When ICAP_COMPRESSION value is TWCP_JPEG

            //ICAP_JPEGPIXELTYPE required
            //ICAP_JPEGQUALITY required
            //ICAP_JPEGSUBSAMPLING required

            #endregion

            #region When ICAP_COMPRESSION value is TWCP_GROUP32D

            //ICAP_CCITTKFACTOR required

            #endregion

            #region When source supports EXTENDED IMAGE INFO

            //ICAP_EXTIMAGEINFO required
            //ICAP_SUPPORTEDEXTIMAGEINFO required
            //Mandatory capabilities: TWEI_DOCUMENTNUMBER, TWEI_PAGENUMBER, TWEI_CAMERA, TWEI_FRAMENUMBER, TWEI_FRAME, TWEI_PIXELFLAVOR, TWEI_PAPERCOUNT, TWEI_PAGESIDE

            #endregion

            #region When source supports Asynchronous Device Events

            //CAP_DEVICEEVENT required

            #endregion

            #region When source supports Stream of images for Live Preview

            //CAP_CAMERAPREVIEWUI required

            #endregion

            #region When source supports Automatic capture

            //CAP_AUTOMATICCAPTURE required
            //CAP_TIMEBEFOREFIRSTCAPTURE required
            //CAP_TIMEBETWEENCAPTURES required

            #endregion

            base.OnCapabilityValueNeeded(e);
        }

        /// <summary>
        /// Invoked when the capability value changed.
        /// </summary>
        /// <param name="e">Information about the capability that was changed.</param>
        protected override void OnCapabilityChanged(CapabilityEventArgs e) {
            switch(e.Capability.CapabilityInfo.Capability) {
                case TwCap.IPixelType:
                    this._ResetCap(TwCap.BitDepth);
                    break;
            }
            base.OnCapabilityChanged(e);
        }

        /// <summary>
        /// Gets or sets the current image layout.
        /// </summary>
        /// <value>
        /// The current image layout.
        /// </value>
        /// <exception cref="System.ArgumentException"></exception>
        protected override RectangleF CurrentImageLayout {
            get {
                return base.CurrentImageLayout;
            }
            set {
                if(value.Right>this.DefaultImageLayout.Right||value.Bottom>this.DefaultImageLayout.Bottom) {
                    throw new ArgumentException();
                }
                base.CurrentImageLayout=value;
            }
        }

        /// <summary>
        /// Gets the default image layout.
        /// </summary>
        /// <value>
        /// The default image layout.
        /// </value>
        protected override RectangleF DefaultImageLayout {
            get {
                return new RectangleF(this._Screen.Bounds.X/this._resolution,this._Screen.Bounds.Y/this._resolution,this._Screen.Bounds.Width/this._resolution,this._Screen.Bounds.Height/this._resolution);
            }
        }

        /// <summary>
        /// If showUI is <c>true</c>, the Source should display its user interface and wait for
        /// the user to initiate an acquisition. If showUI is <c>false</c>,the Source should
        /// immediately begin acquiring data based on its current configuration (a device that requires the
        /// user to push a button on the device,such as a hand-scanner,will be “armed” by this operation and
        /// will assert MSG_XFERREADY as soon as the Source has data ready for transfer). The Source should
        /// fail any attempt to set a capability value (TWRC_FAILURE / TWCC_SEQERROR) until it returns to
        /// State 4 (unless an exception approval exists via a CAP_EXTENDEDCAPS agreement).
        /// Note: If the application has set showUI or CAP_INDICATORS to <c>true</c>, then the Source is
        /// responsible for presenting the user with appropriate progress indicators regarding the
        /// acquisition and transfer process. If showUI is set to <c>true</c>, CAP_INDICATORS is ignored
        /// and progress and errors are always shown.
        /// Note: It is strongly recommended that all Sources support being enabled without their User
        /// Interface if the application requests (showUI = <c>false</c>). But if your
        /// Source cannot be used without its User Interface, it should enable showing the Source
        /// User Interface (just as if showUI = <c>true</c>) but return TWRC_CHECKSTATUS. All Sources,
        /// however, must support the CAP_UICONTROLLABLE. This capability reports whether or
        /// not a Source allows showUI = <c>false</c>. An application can use this capability to know
        /// whether the Source-supplied user interface can be suppressed before it is displayed.
        /// </summary>
        /// <param name="showUI"><c>true</c> if DS should bring up its UI.</param>
        /// <param name="modalUI"><c>true</c> if the DS's UI is modal.</param>
        /// <param name="hwnd">For windows only - Application window handle.</param>
        protected override void OnEnableDS(bool showUI,bool modalUI,IntPtr hwnd) {
            try {
                this._Screen=System.Windows.Forms.Screen.FromHandle(hwnd);
            } catch {
                this._Screen=System.Windows.Forms.Screen.PrimaryScreen;
            }
            if(showUI) {
                var _getCore = typeof(DataSourceCapability).GetMethod("GetCore",BindingFlags.Instance|BindingFlags.NonPublic);
                this._acquireForm=new Forms.AcquireForm(new Forms.AcquireForm.Args {
                    Resolutions=_getCore.Invoke(this[TwCap.XResolution],null) as IEnumerable,
                    PixelTypes=_getCore.Invoke(this[TwCap.IPixelType],null) as IEnumerable,
                    Resolution=(float)this[TwCap.XResolution].Value,
                    PixelType=(TwPixelType)this[TwCap.IPixelType].Value,
                    FeederEnable=(bool)this[TwCap.FeederEnabled].Value,
                    XferCount=(short)this[TwCap.XferCount].Value,
                    BitDepths=_getCore.Invoke(this[TwCap.BitDepth],null) as IEnumerable,
                    BitDepth=(ushort)this[TwCap.BitDepth].Value
                });
                this._acquireForm.FormClosed+=(sender,e) => {
                    this.OnCloseDSReq();
                };
                this._acquireForm.AcquireRequred+=(sender,e) => {
                    this[TwCap.XResolution].Value=e.Args.Resolution;
                    this[TwCap.YResolution].Value=e.Args.Resolution;
                    this[TwCap.IPixelType].Value=e.Args.PixelType;
                    this[TwCap.FeederEnabled].Value=e.Args.FeederEnable;
                    this[(TwCap)0x8001].Value=(short)e.Args.XferCount;
                    this[TwCap.BitDepth].Value=(ushort)e.Args.BitDepth;
                    this.OnXferReady();
                };
                this._acquireForm.Show(System.Windows.Forms.Control.FromHandle(hwnd));
            } else {
                this.OnXferReady();
            }

            base.OnEnableDS(showUI,modalUI,hwnd);
        }

        /// <summary>
        /// If the Source’s user interface is displayed, it should be lowered. The Source returns to State 4 and
        /// is again available for capability negotiation.
        /// </summary>
        /// <param name="hwnd">For windows only - Application window handle.</param>
        protected override void OnDisableDS(IntPtr hwnd) {
            if(this._acquireForm!=null) {
                this._acquireForm.Dispose();
                this._acquireForm=null;
            }
            base.OnDisableDS(hwnd);
        }

        /// <summary>
        /// Invoked to indicate that the Source has data that is ready to be transferred.
        /// </summary>
        protected override void OnXferReady() {
            if((bool)this[TwCap.FeederEnabled].Value&&(short)this[(TwCap)0x8001].Value>0) {
                if((short)this[TwCap.XferCount].Value>0) {
                    this.XferEnvironment.PendingXfers=Math.Min((ushort)(short)this[TwCap.XferCount].Value,(ushort)(short)this[(TwCap)0x8001].Value);
                } else {
                    this.XferEnvironment.PendingXfers=(ushort)(short)this[(TwCap)0x8001].Value;
                }
                this[(TwCap)0x8001].Value=(short)-1;
            }
            base.OnXferReady();
        }

        /// <summary>
        /// Acquire bitmap image.
        /// </summary>
        /// <returns>
        /// The bitmap image.
        /// </returns>
        protected override Bitmap Acquire() {
            var _depth = (ushort)this[TwCap.BitDepth].Value;
            var _format = PixelFormat.Undefined;

            switch((TwPixelType)this[TwCap.IPixelType].Value) {
                case TwPixelType.RGB:
                    _format=new Dictionary<ushort,PixelFormat> {
                        {24, PixelFormat.Format24bppRgb},
                        {48, PixelFormat.Format48bppRgb}}[_depth];
                    break;
            }

            using(var _coreImage = new Bitmap(this._Screen.Bounds.Width,this._Screen.Bounds.Height,_format)) {
                using(var _graphics = Graphics.FromImage(_coreImage)) {
                    _graphics.CopyFromScreen(this._Screen.Bounds.Location,this._Screen.Bounds.Location,this._Screen.Bounds.Size);
                }

                var _xdpi = (float)this[TwCap.XResolution].Value;
                var _ydpi = (float)this[TwCap.YResolution].Value;
                var _image = new Bitmap(
                    (int)(this._Screen.Bounds.Width*_xdpi/this._resolution),
                    (int)(this._Screen.Bounds.Height*_ydpi/this._resolution),
                    _format);
                _image.SetResolution(_xdpi,_ydpi);
                using(var _graphics = Graphics.FromImage(_image)) {
                    _graphics.DrawImage(_coreImage,new Rectangle(new Point(),_image.Size),new Rectangle(new Point(),_coreImage.Size),GraphicsUnit.Pixel);
                }
                return _image;
            }
        }

        private void _SetCap(TwCap cap,Action<DataSourceCapability> action) {
            if(!this._caps.ContainsKey(cap)) {
                action(this[cap]);
                this._caps.Add(cap,this[cap]);
            }
        }

        private void _ResetCap(TwCap cap) {
            if(this._caps.ContainsKey(cap)) {
                this._caps.Remove(cap);
            }
        }

        #region Capability Handlers

        private void _ResolutionCapHandler(DataSourceCapability cap) {
            if(cap.Value==null) {
                cap.Value=new float[] { 75f,this._resolution,100f,150,200f,300f,600f };
                cap.Value=(DefaultValue<float>)this._resolution;
            }
        }

        private void _NativeResolutionCapHandler(DataSourceCapability cap) {
            cap.Value=this._resolution;
        }

        private void _PhysicalWidthCapHandler(DataSourceCapability cap) {
            cap.Value=this._Screen.Bounds.Width/this._resolution;
        }

        private void _PhysicalHeightCapHandler(DataSourceCapability cap) {
            cap.Value=this._Screen.Bounds.Height/this._resolution;
        }

        private void _BitDepthCapHandler(DataSourceCapability cap) {
            var _pixelType = (TwPixelType)this[TwCap.IPixelType].Value;
            switch(_pixelType) {
                case TwPixelType.RGB:
                    if(cap.Value==null) {
                        cap.Value=new ushort[] { 24 };
                        cap.Value=(DefaultValue<ushort>)(24);
                    }
                    break;
            }
        }

        #endregion

        private System.Windows.Forms.Screen _Screen {
            get {
                if(this._screen==null) {
                    this._Screen=System.Windows.Forms.Screen.PrimaryScreen;
                }
                return this._screen;
            }
            set {
                this._screen=value;
                this.CurrentImageLayout=this.DefaultImageLayout;
            }
        }

        private Dictionary<TwCap,Action<DataSourceCapability>> _Handlers {
            get {
                if(this._handlers==null) {
                    this._handlers=new Dictionary<TwCap,Action<DataSourceCapability>> {
                        {TwCap.XResolution, cap => this._ResolutionCapHandler(cap)},
                        {TwCap.YResolution, cap => this._ResolutionCapHandler(cap)},
                        {TwCap.XNativeResolution, cap => this._NativeResolutionCapHandler(cap)},
                        {TwCap.YNativeResolution, cap => this._NativeResolutionCapHandler(cap)},
                        {TwCap.PhysicalWidth, cap => this._PhysicalWidthCapHandler(cap)},
                        {TwCap.PhysicalHeight, cap => this._PhysicalHeightCapHandler(cap)},
                        {TwCap.BitDepth, cap => this._BitDepthCapHandler(cap)}
                    };
                }
                return this._handlers;
            }
        }
    }
}
