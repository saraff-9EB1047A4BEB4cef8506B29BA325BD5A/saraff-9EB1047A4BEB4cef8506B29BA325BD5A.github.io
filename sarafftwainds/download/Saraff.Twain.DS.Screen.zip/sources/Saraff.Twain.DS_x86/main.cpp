#include <Windows.h>
#include "twain.h"

using namespace System;
using namespace System::Runtime::InteropServices;
using namespace Saraff::Twain::DS;

TW_UINT16 TW_CALLINGSTYLE DS_Entry(
	pTW_IDENTITY pOrigin, // source of message
	TW_UINT32 DG, // data group ID: DG_xxxx
	TW_UINT16 DAT, // data argument type: DAT_xxxx
	TW_UINT16 MSG, // message ID: MSG_xxxx
	TW_MEMREF pData // pointer to data
	){
		TwIdentity^ _srcId=(TwIdentity^)Marshal::PtrToStructure(IntPtr(pOrigin),TwIdentity::typeid);
		return (TW_UINT16)DataSourceServices::Current->ProcessRequest(_srcId,(TwDG)DG,(TwDAT)DAT,(TwMSG)MSG,IntPtr(pData));
}
