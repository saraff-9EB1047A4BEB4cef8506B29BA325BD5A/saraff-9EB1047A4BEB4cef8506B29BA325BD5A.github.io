﻿namespace Saraff.Twain.DS.Screen.Forms {
    partial class AcquireForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing&&(components!=null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.acquireButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.feederCheckBox = new System.Windows.Forms.CheckBox();
            this.xferCountNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.resolutionComboBox = new System.Windows.Forms.ComboBox();
            this.resolutionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pixelTypeComboBox = new System.Windows.Forms.ComboBox();
            this.pixelTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bitDepthComboBox = new System.Windows.Forms.ComboBox();
            this.bitDepthBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xferCountNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resolutionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pixelTypeBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bitDepthBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // acquireButton
            // 
            this.acquireButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.acquireButton.Location = new System.Drawing.Point(268, 133);
            this.acquireButton.Name = "acquireButton";
            this.acquireButton.Size = new System.Drawing.Size(75, 23);
            this.acquireButton.TabIndex = 0;
            this.acquireButton.Text = "Acquire";
            this.acquireButton.UseVisualStyleBackColor = true;
            this.acquireButton.Click += new System.EventHandler(this.acquireButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Resolution";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pixel Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(170, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Documents Count";
            // 
            // feederCheckBox
            // 
            this.feederCheckBox.AutoSize = true;
            this.feederCheckBox.Location = new System.Drawing.Point(6, 20);
            this.feederCheckBox.Name = "feederCheckBox";
            this.feederCheckBox.Size = new System.Drawing.Size(95, 17);
            this.feederCheckBox.TabIndex = 7;
            this.feederCheckBox.Text = "Feeder Enable";
            this.feederCheckBox.UseVisualStyleBackColor = true;
            this.feederCheckBox.CheckedChanged += new System.EventHandler(this.feederCheckBox_CheckedChanged);
            // 
            // xferCountNumericUpDown
            // 
            this.xferCountNumericUpDown.Enabled = false;
            this.xferCountNumericUpDown.Location = new System.Drawing.Point(107, 19);
            this.xferCountNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.xferCountNumericUpDown.Name = "xferCountNumericUpDown";
            this.xferCountNumericUpDown.Size = new System.Drawing.Size(57, 20);
            this.xferCountNumericUpDown.TabIndex = 8;
            this.xferCountNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.xferCountNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // resolutionComboBox
            // 
            this.resolutionComboBox.DataSource = this.resolutionBindingSource;
            this.resolutionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.resolutionComboBox.FormattingEnabled = true;
            this.resolutionComboBox.Location = new System.Drawing.Point(72, 12);
            this.resolutionComboBox.Name = "resolutionComboBox";
            this.resolutionComboBox.Size = new System.Drawing.Size(94, 21);
            this.resolutionComboBox.TabIndex = 9;
            // 
            // pixelTypeComboBox
            // 
            this.pixelTypeComboBox.DataSource = this.pixelTypeBindingSource;
            this.pixelTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pixelTypeComboBox.FormattingEnabled = true;
            this.pixelTypeComboBox.Location = new System.Drawing.Point(72, 39);
            this.pixelTypeComboBox.Name = "pixelTypeComboBox";
            this.pixelTypeComboBox.Size = new System.Drawing.Size(121, 21);
            this.pixelTypeComboBox.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(172, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "dpi";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.feederCheckBox);
            this.groupBox1.Controls.Add(this.xferCountNumericUpDown);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(12, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(331, 53);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ADF";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(211, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Bit Depth";
            // 
            // bitDepthComboBox
            // 
            this.bitDepthComboBox.DataSource = this.bitDepthBindingSource;
            this.bitDepthComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.bitDepthComboBox.FormattingEnabled = true;
            this.bitDepthComboBox.Location = new System.Drawing.Point(268, 39);
            this.bitDepthComboBox.Name = "bitDepthComboBox";
            this.bitDepthComboBox.Size = new System.Drawing.Size(75, 21);
            this.bitDepthComboBox.TabIndex = 14;
            // 
            // AcquireForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 168);
            this.Controls.Add(this.bitDepthComboBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pixelTypeComboBox);
            this.Controls.Add(this.resolutionComboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.acquireButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AcquireForm";
            this.Text = "AcquireForm";
            ((System.ComponentModel.ISupportInitialize)(this.xferCountNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resolutionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pixelTypeBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bitDepthBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button acquireButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox feederCheckBox;
        private System.Windows.Forms.NumericUpDown xferCountNumericUpDown;
        private System.Windows.Forms.ComboBox resolutionComboBox;
        private System.Windows.Forms.ComboBox pixelTypeComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.BindingSource resolutionBindingSource;
        private System.Windows.Forms.BindingSource pixelTypeBindingSource;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox bitDepthComboBox;
        private System.Windows.Forms.BindingSource bitDepthBindingSource;
    }
}