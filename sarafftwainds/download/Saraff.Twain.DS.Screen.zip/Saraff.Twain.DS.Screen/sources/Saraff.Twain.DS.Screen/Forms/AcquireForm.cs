﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Saraff.Twain.DS.Screen.Forms {

    internal sealed partial class AcquireForm:Form {

        public AcquireForm(Args args) {
            InitializeComponent();
            this.resolutionBindingSource.DataSource=args.Resolutions;
            this.resolutionBindingSource.Position=this.resolutionBindingSource.IndexOf(args.Resolution);
            this.pixelTypeBindingSource.DataSource=args.PixelTypes;
            this.pixelTypeBindingSource.Position=this.pixelTypeBindingSource.IndexOf(args.PixelType);
            this.feederCheckBox.Checked=args.FeederEnable;
            this.xferCountNumericUpDown.Value=Math.Abs(args.XferCount);
            this.bitDepthBindingSource.DataSource=args.BitDepths;
            this.bitDepthBindingSource.Position=this.bitDepthBindingSource.IndexOf(args.BitDepth);
        }

        private void OnAcquireRequred(AcquireEventArgs e) {
            if(this.AcquireRequred!=null) {
                this.AcquireRequred(this,e);
            }
        }

        private void acquireButton_Click(object sender,EventArgs e) {
            try {
                this.OnAcquireRequred(new AcquireEventArgs {
                    Args=new Args {
                        Resolution=(float)this.resolutionBindingSource.Current,
                        PixelType=(TwPixelType)this.pixelTypeBindingSource.Current,
                        FeederEnable=this.feederCheckBox.Checked,
                        XferCount=(int)this.xferCountNumericUpDown.Value,
                        BitDepth=(ushort)this.bitDepthBindingSource.Current
                    }
                });
            }catch(Exception ex) {
                Debug.WriteLine("{0}{1}: {2}{0}{3}{0}",Environment.NewLine,ex.GetType().Name,ex.Message,ex.StackTrace);
            }
        }

        private void feederCheckBox_CheckedChanged(object sender,EventArgs e) {
            try {
                this.xferCountNumericUpDown.Enabled=this.feederCheckBox.Checked;
            } catch(Exception ex) {
                Debug.WriteLine("{0}{1}: {2}{0}{3}{0}",Environment.NewLine,ex.GetType().Name,ex.Message,ex.StackTrace);
            }
        }

        public event EventHandler<AcquireEventArgs> AcquireRequred;

        internal sealed class Args {

            public IEnumerable Resolutions {
                get;
                set;
            }

            public float Resolution {
                get;
                set;
            }

            public IEnumerable PixelTypes {
                get;
                set;
            }

            public TwPixelType PixelType {
                get;
                set;
            }

            public int XferCount {
                get;
                set;
            }

            public bool FeederEnable {
                get;
                set;
            }

            public IEnumerable BitDepths {
                get;
                set;
            }

            public ushort BitDepth {
                get;
                set;
            }
        }

        internal sealed class AcquireEventArgs:EventArgs {

            public Args Args {
                get;
                set;
            }
        }
    }
}
